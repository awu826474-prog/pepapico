# 空项目

## 用户需求
用Python制作五子棋游戏，包含15x15棋盘、双人对战模式和AI棋手（minimax alpha-beta剪枝），命令行界面

## 项目路径
D:\Users\hobbibean\Documents\micro\mixed\Byte_cp\test-gomoku

这是一个空目录，需要从零开始创建所有文件。