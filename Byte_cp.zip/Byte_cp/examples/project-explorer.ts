/**
 * Byte_cp 完整教学例程 — 项目探索与 Agent 协作
 *
 * 演示：
 *   1. 创建 ByteOS 实例，注册 Provider
 *   2. 创建协调者 Agent，读取项目结构并形成认知
 *   3. 让协调者创建子 Agent（手动创建 + 通过 LLM 引导创建）
 *   4. 并行执行子任务
 *   5. 自主模式：Agent 等待信号，无需人工触发
 *   6. 回收子 Agent，查看压缩记忆
 *
 * 运行：
 *   node --experimental-strip-types examples/project-explorer.ts <项目路径> [openrouter|copilot]
 *
 * 示例：
 *   node --experimental-strip-types examples/project-explorer.ts D:\my-project openrouter
 */

import { readFileSync, existsSync } from 'node:fs'
import { resolve, join, basename } from 'node:path'
import {
  ByteOS,
  createOpenRouter,
  createCopilot,
  authenticateCopilot,
  bashTool,
  fileReadTool,
  fileWriteTool,
  createSubAgentTool,
} from '../src/index.ts'
import type { AgentLoopResult } from '../src/index.ts'

// ============================================================
//  0. CLI 参数解析
// ============================================================

const [, , projectPathArg, providerArg] = process.argv
const projectPath = resolve(projectPathArg ?? '.')
const providerChoice = (providerArg ?? 'openrouter') as 'openrouter' | 'copilot'

if (!existsSync(projectPath)) {
  console.error(`❌ 路径不存在: ${projectPath}`)
  process.exit(1)
}

console.log(`\n${'═'.repeat(60)}`)
console.log(`  Byte_cp 项目探索教程`)
console.log(`  项目路径: ${projectPath}`)
console.log(`  Provider: ${providerChoice}`)
console.log(`${'═'.repeat(60)}\n`)

// ============================================================
//  1. 初始化 ByteOS
// ============================================================

/**
 * ByteOSConfig 可选项：
 *   onEvent            — 全局 Agent 事件监听（进度/状态变更/日志）
 *   onPermissionRequest — 危险工具调用前拦截，前端展示确认弹窗
 *   autoApproveLevel   — 'low'(默认): 低风险自动放行, 'medium': 中风险也自动放行
 *   routingRules       — 自定义模型路由规则（按标签/难度选择不同模型）
 */
const os = new ByteOS({
  autoApproveLevel: 'low',
  onEvent: (event) => {
    if (event.type === 'progress' && event.content) {
      process.stdout.write(event.content) // 流式输出
    } else if (event.type === 'log') {
      console.log(`  [LOG] ${event.message}`)
    } else if (event.type === 'status_change') {
      console.log(`  [AGENT:${event.agentId?.slice(-6)}] ${event.from} → ${event.to}`)
    }
  },
  onPermissionRequest: (req) => {
    // 这里可以集成 TUI 的确认对话框；本例直接自动允许（教学用）
    console.warn(`\n  ⚠ 权限请求: [${req.risk}] ${req.description}`)
    console.warn(`    工具: ${req.tool}, 自动放行...`)
    os.permissionGuard.resolve(req.id, { action: 'allow' })
  },
})

// ============================================================
//  2. 注册 Provider
// ============================================================

/**
 * 注册 OpenRouter Provider（支持数百个模型）
 * API Key 从环境变量或本地文件读取
 */
async function setupProvider() {
  if (providerChoice === 'openrouter') {
    const apiKey =
      process.env.OPENROUTER_API_KEY ??
      (existsSync('.openrouter-key') ? readFileSync('.openrouter-key', 'utf-8').trim() : null)

    if (!apiKey) {
      console.error('❌ 需要 OPENROUTER_API_KEY 环境变量或 .openrouter-key 文件')
      process.exit(1)
    }

    const provider = createOpenRouter({ apiKey })
    console.log('✓ OpenRouter Provider 已注册')
    return { provider, model: 'anthropic/claude-sonnet-4-5' }
  }

  if (providerChoice === 'copilot') {
    const tokenPath = join(process.cwd(), '.copilot-token')
    let token: string | null = null

    if (existsSync(tokenPath)) {
      token = readFileSync(tokenPath, 'utf-8').trim()
    } else {
      // GitHub Copilot OAuth Device Flow
      console.log('需要授权 GitHub Copilot...')
      const codeRes = await fetch(
        'https://github.com/login/device/code?client_id=Ov23li8tweQw6odWQebz&scope=read:user',
        { method: 'POST', headers: { Accept: 'application/json' } },
      ).then((r) => r.json() as Promise<{ device_code: string; user_code: string; verification_uri: string }>)

      console.log(`\n  访问: ${codeRes.verification_uri}`)
      console.log(`  输入代码: ${codeRes.user_code}\n`)

      const auth = await authenticateCopilot(codeRes.device_code)
      token = auth.access_token
      readFileSync // keep import alive
      // writeFileSync(tokenPath, token)  // 可取消注释以持久化
    }

    const provider = createCopilot({ token: token! })
    console.log('✓ GitHub Copilot Provider 已注册')
    return { provider, model: 'claude-sonnet-4-5' }
  }

  throw new Error(`未知 provider: ${providerChoice}`)
}

// ============================================================
//  3. 构建项目感知工具（扫描目录结构）
// ============================================================

import { readdir, stat } from 'node:fs/promises'

async function buildProjectTree(root: string, depth = 0, maxDepth = 3): Promise<string> {
  if (depth > maxDepth) return ''
  const entries = await readdir(root, { withFileTypes: true })
  const lines: string[] = []
  const indent = '  '.repeat(depth)

  // 忽略常见无关目录
  const ignore = new Set(['node_modules', '.git', '.next', 'dist', 'build', '__pycache__', '.venv', 'venv'])

  for (const entry of entries) {
    if (ignore.has(entry.name)) {
      lines.push(`${indent}${entry.name}/ [已忽略]`)
      continue
    }
    if (entry.isDirectory()) {
      lines.push(`${indent}${entry.name}/`)
      const sub = await buildProjectTree(join(root, entry.name), depth + 1, maxDepth)
      if (sub) lines.push(sub)
    } else {
      const s = await stat(join(root, entry.name))
      const size = s.size > 1024 ? `${(s.size / 1024).toFixed(1)}KB` : `${s.size}B`
      lines.push(`${indent}${entry.name} (${size})`)
    }
  }
  return lines.join('\n')
}

// ============================================================
//  主流程
// ============================================================

async function main() {
  const { provider, model } = await setupProvider()

  // ----------------------------------------------------------
  //  步骤 A: 创建协调者 Agent（coordinator）
  // ----------------------------------------------------------
  /**
   * createAgent() 参数说明：
   *
   *   name        — 显示名称
   *   role        — 'coordinator'(有子agent) | 'worker'(执行任务) | 'standalone'(独立)
   *   systemPrompt — 定义 agent 的行为边界和能力
   *   provider    — 使用的模型 Provider 实例
   *   model       — 模型名称
   *   tools       — 可用工具列表（不填 + builtinTools:true 则附带内置4个工具）
   *   watchTags   — 信号权限标签（哪些信号能唤醒这个 agent）
   *   autonomous  — 自主模式配置
   *   builtinTools — true: 自动附带 bash/file_read/file_write/web_fetch
   */
  const coordinator = os.createAgent({
    name: 'arch-coordinator',
    role: 'coordinator',
    systemPrompt: `你是项目架构分析协调者。你的工作是：
1. 读取并理解项目结构
2. 将工作分解为子任务，分配给子 Agent
3. 综合子 Agent 的结果，输出最终报告

项目根目录: ${projectPath}
当前日期: ${new Date().toLocaleDateString('zh-CN')}

规则：
- 使用 file_read 工具读取文件内容
- 使用 bash 工具执行分析命令（如 \`find\`, \`wc -l\`, \`git log\`）
- 用中文回答`,
    provider,
    model,
    builtinTools: true,
    watchTags: ['agent:wake', 'fs:watch', 'project:analyze'],
    autonomous: {
      enabled: false, // 先关闭自主模式，后面手动演示
      triggers: [{ type: 'signal', tags: ['project:analyze'] }],
      maxAutoRuns: 5,
      autoApproveTools: ['file_read', 'bash'],
    },
  })

  console.log(`✓ 协调者 Agent 已创建`)
  console.log(`  ID: ${coordinator.id}`)
  console.log(`  WatchTags: [${[...coordinator.watchTags].join(', ')}]`)
  console.log(`  状态: ${coordinator.status}\n`)

  // ----------------------------------------------------------
  //  步骤 B: 扫描项目结构，作为上下文传入
  // ----------------------------------------------------------
  console.log('─'.repeat(50))
  console.log('📁 扫描项目结构...')
  const projectTree = await buildProjectTree(projectPath)
  const projectName = basename(projectPath)

  console.log(`\n${projectName}/\n${projectTree}\n`)

  // ----------------------------------------------------------
  //  步骤 C: 运行协调者 — 基础项目认知
  // ----------------------------------------------------------
  console.log('─'.repeat(50))
  console.log('🧠 [Phase 1] 协调者分析项目结构...\n')

  /**
   * os.run(agent, message, options?) 参数说明：
   *   agent   — 目标 Agent 实例
   *   message — 用户消息（本次任务）
   *   options — AgentLoopOptions:
   *               context.cwd   — 工具执行的工作目录
   *               maxTurns      — 覆盖 agent 的最大轮次
   *               returnToIdle  — 完成后是否回 idle（默认 true）
   *
   * 返回值 AgentLoopResult:
   *   finalMessage   — agent 的最终回复
   *   totalTurns     — 执行了多少轮
   *   totalTokens    — 消耗的 token 数
   *   aborted        — 是否被中断
   */
  const phase1: AgentLoopResult = await os.run(
    coordinator,
    `请分析以下项目，形成基本认知并输出结构化报告：

项目名称: ${projectName}
项目路径: ${projectPath}

目录树:
\`\`\`
${projectName}/
${projectTree}
\`\`\`

请完成：
1. 识别项目类型（Web前端/后端/全栈/CLI/库/数据分析/其他）
2. 识别主要技术栈（语言、框架、主要依赖）
3. 描述核心模块及其职责（最多5个）
4. 评估代码规模（文件数、大致行数）
5. 识别可能的入口文件

如需了解细节，请使用 file_read 工具读取关键文件（如 package.json, README.md, main.py 等）。`,
    { context: { cwd: projectPath } },
  )

  console.log('\n\n─'.repeat(50))
  console.log('📊 项目认知报告:\n')
  console.log(phase1.finalMessage)
  console.log(`\n  [统计] 轮次: ${phase1.totalTurns}, Tokens: ${phase1.totalTokens}`)

  // ----------------------------------------------------------
  //  步骤 D-1: 手动创建子 Agent（程序化控制）
  // ----------------------------------------------------------
  console.log('\n' + '─'.repeat(50))
  console.log('🔧 [Phase 2] 手动创建子 Agent...\n')

  /**
   * agent.createChild(config) — 父 Agent 创建子 Agent
   *
   * 关键机制：
   * - 子 Agent 自动继承父 Agent 的所有 watchTags
   * - 子 Agent 出现在父 Agent 的 children 列表中
   * - 后续可用 os.recycleAgent(parentId, childId) 回收
   *
   * 注意：createChild 只创建 Agent 对象，不会自动注册到 runtime，
   * 需要手动调用 os.runtime.registerAgent(child) 才能接收信号
   */
  const depAnalyzer = coordinator.createChild({
    name: 'dep-analyzer',
    role: 'worker',
    systemPrompt: `你是依赖分析专家。分析项目的依赖关系，识别：
- 直接依赖 vs 开发依赖
- 过时的依赖（如能判断）
- 潜在的安全风险包
- 依赖的许可证类型（如能识别）

项目路径: ${projectPath}
只输出分析结果，不需要确认或询问。`,
    provider,
    model,
    builtinTools: true,
    watchTags: ['dep:analyze'], // 子 agent 会额外继承父节点的 watchTags
  })

  // 注册到 runtime（使其可接收信号）
  os.runtime.registerAgent(depAnalyzer)
  os.manager.register(depAnalyzer.id, depAnalyzer.role, depAnalyzer.getDepth())

  console.log(`  ✓ dep-analyzer 已创建`)
  console.log(`  ID: ${depAnalyzer.id}`)
  console.log(`  WatchTags: [${[...depAnalyzer.watchTags].join(', ')}]`)
  console.log(`  父节点继承的 Tags: agent:wake, fs:watch, project:analyze\n`)

  const codeReviewer = coordinator.createChild({
    name: 'code-reviewer',
    role: 'worker',
    systemPrompt: `你是代码质量审查专家。分析项目代码质量：
- 识别可能的代码异味（Code Smell）
- 检查是否有明显的安全问题
- 评估代码可读性
- 提出最高优先级的改进建议（最多3条）

项目路径: ${projectPath}
只输出审查结果，简洁直接。`,
    provider,
    model,
    builtinTools: true,
    watchTags: ['code:review'],
  })

  os.runtime.registerAgent(codeReviewer)
  os.manager.register(codeReviewer.id, codeReviewer.role, codeReviewer.getDepth())

  console.log(`  ✓ code-reviewer 已创建`)

  // ----------------------------------------------------------
  //  步骤 D-2: 并行运行子 Agent
  // ----------------------------------------------------------
  console.log('\n  🚀 并行执行子任务...\n')

  /**
   * os.runParallel(parent, tasks) — 并行运行多个子 Agent
   *
   * 内部使用 Promise.allSettled，所有子任务同时执行
   * 每个 task 需要: name, systemPrompt, message, watchTags?
   *
   * 注意：这会自动为每个 task 创建新的子 Agent 并运行
   * 如果你想运行已有的子 Agent，请用 Promise.all + os.run()
   */
  const parallelResults = await Promise.allSettled([
    os.run(depAnalyzer, `分析 ${projectPath} 的依赖配置文件（package.json/requirements.txt/go.mod 等）`, {
      context: { cwd: projectPath },
    }),
    os.run(codeReviewer, `审查 ${projectPath} 中最重要的源文件（根据文件大小和位置判断），提供代码质量报告`, {
      context: { cwd: projectPath },
    }),
  ])

  // 收集结果
  const [depResult, reviewResult] = parallelResults.map((r) =>
    r.status === 'fulfilled' ? r.value : { finalMessage: `[失败] ${(r as PromiseRejectedResult).reason}`, totalTurns: 0, totalTokens: 0 },
  )

  console.log('\n─'.repeat(50))
  console.log('📦 依赖分析结果:\n')
  console.log(depResult.finalMessage)

  console.log('\n─'.repeat(50))
  console.log('🔍 代码审查结果:\n')
  console.log(reviewResult.finalMessage)

  // ----------------------------------------------------------
  //  步骤 D-3: 通过 LLM 引导协调者创建子 Agent
  //             （让 AI 自己决定要创建什么 Agent）
  // ----------------------------------------------------------
  console.log('\n' + '─'.repeat(50))
  console.log('🤖 [Phase 3] 引导协调者自行规划并创建子 Agent...\n')

  /**
   * 这是核心的"AI 引导创建子 Agent"模式：
   *
   * 1. 给协调者附加 sub_agent 工具（它能调用此工具创建子任务）
   * 2. 在 prompt 中告诉协调者它可以创建子 Agent
   * 3. 协调者根据任务复杂度自主决定是否以及如何拆分
   *
   * createSubAgentTool 接受：
   *   parentAgent  — 父 Agent（子 Agent 会挂载在其下）
   *   providerMap  — provider 映射（子 Agent 可选择不同 provider）
   */
  const providerMap = new Map([['default', { provider, model }]])
  const subAgentTool = createSubAgentTool(coordinator, providerMap)

  // 临时给协调者附加 sub_agent 工具
  coordinator.tools.push(subAgentTool)

  const phase3: AgentLoopResult = await os.run(
    coordinator,
    `基于你之前对项目 "${projectName}" 的分析，以及子 Agent 报告的依赖情况和代码质量：

你现在需要生成一份**完整的项目改进路线图**。

如果任务足够复杂（例如需要详细分析多个模块），你可以使用 sub_agent 工具创建子 Agent 来处理子任务。
如果你认为自己可以直接完成，也可以不创建子 Agent。

依赖分析结果摘要:
${depResult.finalMessage.slice(0, 800)}...

代码审查结果摘要:
${reviewResult.finalMessage.slice(0, 800)}...

请输出：
1. 最紧急的3个改进项（含具体行动步骤）
2. 中期优化建议（1-3个月）
3. 长期架构演进方向`,
    { context: { cwd: projectPath } },
  )

  // 移除临时工具
  const idx = coordinator.tools.findIndex((t) => t.name === 'sub_agent')
  if (idx !== -1) coordinator.tools.splice(idx, 1)

  console.log('\n─'.repeat(50))
  console.log('🗺 项目改进路线图:\n')
  console.log(phase3.finalMessage)

  // ----------------------------------------------------------
  //  步骤 E: 查看 Agent 树结构
  // ----------------------------------------------------------
  console.log('\n' + '─'.repeat(50))
  console.log('🌲 Agent 层级树:\n')

  function printTree(node: ReturnType<typeof coordinator.getHierarchy>, indent = '') {
    const tags = node.watchTags?.length ? ` [${node.watchTags.slice(0, 3).join(',')}]` : ''
    const queue = node.signalQueueSize ? ` 📬${node.signalQueueSize}` : ''
    console.log(`${indent}${node.name} (${node.status})${tags}${queue}`)
    for (const child of node.children ?? []) {
      printTree(child, indent + '  └─ ')
    }
  }

  printTree(coordinator.getHierarchy())

  // ----------------------------------------------------------
  //  步骤 F: 自主模式演示
  // ----------------------------------------------------------
  console.log('\n' + '─'.repeat(50))
  console.log('⚡ [Phase 4] 自主模式演示...\n')

  /**
   * 自主模式工作原理：
   * 1. startAutonomous(agent) 启动后台循环
   * 2. Agent 进入 idle 状态，等待信号
   * 3. 当收到匹配 watchTags 的信号时，自动唤醒并执行任务
   * 4. 完成后回到 idle，继续等待下一个信号
   * 5. stopAutonomous(agentId) 停止循环
   *
   * 注意：自主模式下，agent.autonomous.enabled 必须为 true
   */

  // 创建一个专用的监控 Agent
  const monitorAgent = os.createAgent({
    name: 'file-monitor',
    role: 'standalone',
    systemPrompt: `你是文件变更监控器。当收到 fs:watch 信号时，
分析信号中描述的文件变更并给出简要评估。
用一段话描述变更的影响，然后返回 idle。`,
    provider,
    model,
    builtinTools: false, // 监控 agent 不需要工具
    watchTags: ['fs:watch', 'file:changed'],
    autonomous: {
      enabled: true,
      triggers: [{ type: 'signal', tags: ['fs:watch', 'file:changed'] }],
      maxAutoRuns: 3,
      autoApproveTools: [],
    },
  })

  console.log(`  ✓ 监控 Agent 已创建: ${monitorAgent.name} (${monitorAgent.id.slice(-8)})`)
  console.log(`  WatchTags: [${[...monitorAgent.watchTags].join(', ')}]`)
  console.log(`  监控 Agent 进入自主模式...`)

  // 启动自主模式
  os.startAutonomous(monitorAgent, undefined)

  // 等待 agent 进入 idle
  await new Promise((r) => setTimeout(r, 500))
  console.log(`  状态: ${monitorAgent.status} (等待信号中)`)

  // 发送模拟的文件变更信号
  console.log('\n  📡 发送文件变更信号...')
  const woken = await os.wakeAgent(
    monitorAgent.id,
    'demo-system',
    {
      event: 'file_modified',
      path: join(projectPath, 'README.md'),
      message: `文件 README.md 发生变更，请评估影响`,
    },
  )
  console.log(`  唤醒结果: ${woken ? '✓ 已唤醒' : '✗ 唤醒失败'}`)

  // 等待 agent 完成处理
  await new Promise((r) => setTimeout(r, 3000))
  console.log(`  处理后状态: ${monitorAgent.status}`)

  // 停止自主模式
  os.stopAutonomous(monitorAgent.id)
  console.log(`  自主模式已停止`)

  // ----------------------------------------------------------
  //  步骤 G: 回收子 Agent，查看压缩记忆
  // ----------------------------------------------------------
  console.log('\n' + '─'.repeat(50))
  console.log('♻️  [Phase 5] 回收子 Agent...\n')

  /**
   * recycleAgent(parentId, childId) 工作流：
   * 1. 停止子 Agent 的自主循环
   * 2. 压缩子 Agent 的对话历史为摘要
   * 3. 将压缩记忆封存到父 Agent 的 archivedChildren
   * 4. 从 runtime 注销子 Agent
   * 5. 子 Agent 状态变为 'recycled'
   *
   * 返回 CompressedMemory | null
   */
  const depMemory = os.recycleAgent(coordinator.id, depAnalyzer.id)
  if (depMemory) {
    console.log(`  ✓ dep-analyzer 已回收`)
    console.log(`  压缩摘要: ${depMemory.summary}`)
    console.log(`  关键结论数: ${depMemory.keyResults.length}`)
    console.log(`  工具使用: ${depMemory.toolHistory.map((t) => `${t.tool}×${t.count}`).join(', ')}`)
    console.log(`  累计 Tokens: ${depMemory.totalTokens}`)
  }

  const reviewMemory = os.recycleAgent(coordinator.id, codeReviewer.id)
  if (reviewMemory) {
    console.log(`\n  ✓ code-reviewer 已回收`)
    console.log(`  压缩摘要: ${reviewMemory.summary.slice(0, 120)}...`)
  }

  console.log(`\n  协调者封存的子 Agent 记忆数: ${coordinator.archivedChildren.length}`)

  // ----------------------------------------------------------
  //  步骤 H: 运行时状态报告
  // ----------------------------------------------------------
  console.log('\n' + '─'.repeat(50))
  console.log('📈 运行时状态:\n')

  const status = os.getRuntimeStatus()
  console.log(`  总 Agent 数:     ${status.totalAgents}`)
  console.log(`  Idle 中:         ${status.idleAgents}`)
  console.log(`  运行中:          ${status.runningAgents}`)
  console.log(`  自主模式:        ${status.autonomousAgents}`)
  console.log(`  信号总线 - 总发送: ${status.signalBusStats.totalSent}`)
  console.log(`  信号总线 - 总送达: ${status.signalBusStats.totalDelivered}`)

  console.log('\n  计费报告:')
  console.log(os.printUsageReport())

  // ----------------------------------------------------------
  //  步骤 I: Plan Mode 演示
  // ----------------------------------------------------------
  console.log('─'.repeat(50))
  console.log('📋 [Phase 6] Plan Mode 演示...\n')

  /**
   * Plan Mode 允许你安全地编辑计划树：
   * 1. createPlanSnapshot() — 复制当前状态为草稿
   * 2. 在草稿上做修改（添加/删除/修改目标节点）
   * 3. computePlanDiff() — 计算草稿与原始的差分
   * 4. applyPlanDiff() — 将差分应用到原始树
   *
   * 这样可以在不影响正在运行的 agent 的前提下预览变更。
   */
  const snapshot = os.createPlanSnapshot()
  console.log(`  ✓ 计划快照已创建: ${snapshot.id}`)

  // 在草稿上添加一个目标节点
  os.planMode.addDraftGoal(snapshot.id, {
    id: `goal-${Date.now()}`,
    agentId: 'future-security-auditor',
    goal: '执行安全漏洞扫描',
    status: 'pending',
    subGoals: [],
  }, undefined)

  // 计算差分
  const diff = os.getPlanDiff(snapshot.id)
  if (diff) {
    console.log(`\n  计划差分:`)
    console.log(`  + 新增节点: ${diff.added.length} 个`)
    console.log(`  - 删除节点: ${diff.removed.length} 个`)
    console.log(`  ~ 修改节点: ${diff.modified.length} 个`)
    console.log()
    console.log(os.planMode.printDiff(diff))
  }

  // 丢弃快照（不应用）
  os.planMode.discardSnapshot(snapshot.id)
  console.log(`  快照已丢弃（演示用，不实际应用）`)

  // ----------------------------------------------------------
  //  完成
  // ----------------------------------------------------------
  console.log('\n' + '═'.repeat(60))
  console.log('  ✅ 教程完成！')
  console.log('═'.repeat(60))
  console.log(`
  下一步可以尝试：

  1. 运行 TUI:
     npm run tui

  2. 修改 watchTags 来控制哪些信号能唤醒哪个 Agent

  3. 在自主模式下设置定时触发：
     autonomous: { triggers: [{ type: 'schedule', intervalMs: 60000 }] }

  4. 使用 /plan snapshot → /plan diff → /plan apply
     在 TUI 中安全地编辑 Agent 计划树

  5. 查看完整 API:
     src/index.ts  — ByteOS 门面类
     src/os/       — Agent OS 核心
     src/provider/ — 模型 Provider 层
`)
}

main().catch((err) => {
  console.error('\n❌ 运行错误:', err)
  process.exit(1)
})
