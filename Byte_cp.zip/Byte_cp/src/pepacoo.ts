#!/usr/bin/env node
/**
 * PepaPico — 项目托管 Agent 系统
 *
 * 启动:
 *   npm run pico                    ← 托管当前目录
 *   npm run pico -- D:\my-project   ← 托管指定项目
 *
 * 终端内命令管理 Provider、切换项目、操控 Agent 树。
 */

import * as readline from 'node:readline'
import { resolve, basename } from 'node:path'
import { existsSync, readFileSync } from 'node:fs'

import {
  PepacooWorkspace,
} from './workspace.ts'
import type {
  ModelsConfig,
  ProvidersConfig,
  AgentsConfig,
  ProjectScan,
  WorkspaceMeta,
  SerializedGoalNode,
} from './workspace.ts'

import {
  ByteOS,
  Agent,
  createOpenRouter,
  createCopilot,
  createSubAgentTool,
} from './index.ts'
import type {
  AgentLoopResult,
  ModelProvider,
  PermissionRequest,
} from './index.ts'

// ============================================================
//  ANSI 色彩
// ============================================================

const C = {
  reset: '\x1b[0m',
  bold: '\x1b[1m',
  dim: '\x1b[2m',
  red: '\x1b[31m',
  green: '\x1b[32m',
  yellow: '\x1b[33m',
  blue: '\x1b[34m',
  magenta: '\x1b[35m',
  cyan: '\x1b[36m',
  white: '\x1b[37m',
  bgBlue: '\x1b[44m',
  bgGreen: '\x1b[42m',
  bgYellow: '\x1b[43m',
}

function log(msg: string) { console.log(msg) }
function info(msg: string) { log(`${C.cyan}ℹ${C.reset} ${msg}`) }
function ok(msg: string) { log(`${C.green}✓${C.reset} ${msg}`) }
function warn(msg: string) { log(`${C.yellow}⚠${C.reset} ${msg}`) }
function err(msg: string) { log(`${C.red}✗${C.reset} ${msg}`) }
function header(msg: string) { log(`\n${C.bgBlue}${C.white}${C.bold} ${msg} ${C.reset}\n`) }
function divider() { log(`${C.dim}${'─'.repeat(60)}${C.reset}`) }

// ============================================================
//  readline 助手
// ============================================================

let rl: readline.Interface

function initRL() {
  rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout,
  })
}

function ask(prompt: string): Promise<string> {
  return new Promise((res) => rl.question(`${C.cyan}?${C.reset} ${prompt}`, (ans) => res(ans.trim())))
}

function confirm(prompt: string): Promise<boolean> {
  return new Promise((res) => rl.question(`${C.yellow}?${C.reset} ${prompt} [Y/n] `, (ans) => {
    res(ans.trim().toLowerCase() !== 'n')
  }))
}

// ============================================================
//  Provider 创建助手
// ============================================================

function createProvider(
  providersCfg: ProvidersConfig,
  name: string,
): ModelProvider {
  const cfg = providersCfg.providers[name]
  if (!cfg) throw new Error(`Provider "${name}" 未在 providers.json 中配置`)

  switch (cfg.type) {
    case 'openrouter':
    case 'openai-compatible': {
      const apiKey = resolveEnvVar(cfg.apiKey ?? '')
      if (!apiKey) throw new Error(`Provider "${name}" 缺少 apiKey`)
      return createOpenRouter({ apiKey, ...(cfg.baseUrl ? { baseUrl: cfg.baseUrl } : {}) })
    }
    case 'copilot': {
      const token = resolveEnvVar(cfg.token ?? cfg.apiKey ?? '')
      if (!token) throw new Error(`Provider "${name}" 缺少 token`)
      return createCopilot({ token })
    }
    default:
      throw new Error(`不支持的 provider 类型: ${cfg.type}`)
  }
}

/** 解析环境变量引用 ${VAR} */
function resolveEnvVar(value: string): string {
  if (value.startsWith('${') && value.endsWith('}')) {
    const envName = value.slice(2, -1)
    return process.env[envName] ?? ''
  }
  return value
}

// ============================================================
//  核心流程
// ============================================================

/**
 * Phase 1: 初始化工作区
 */
function doInit(projectPath: string, opts: { provider?: string; model?: string; apiKey?: string }): PepacooWorkspace {
  const ws = new PepacooWorkspace(projectPath)

  if (ws.isInitialized()) {
    warn(`.pepacoo/ 已存在，将使用现有工作区`)
    return ws
  }

  ws.init({
    provider: opts.provider,
    model: opts.model,
    apiKey: opts.apiKey,
  })

  ok(`.pepacoo/ 已创建于 ${ws.projectPath}`)
  info(`配置文件:`)
  log(`  ${C.dim}models.json${C.reset}       — 各级默认模型配置`)
  log(`  ${C.dim}providers.json${C.reset}    — Provider 凭证`)
  log(`  ${C.dim}agents.json${C.reset}       — Agent 行为配置`)
  log(`  ${C.dim}permissions.json${C.reset}  — 权限策略`)
  log(`  ${C.dim}scan.json${C.reset}         — 项目扫描规则`)
  log(`  ${C.dim}workspace.json${C.reset}    — 工作区元信息`)

  return ws
}

/**
 * Phase 2: 扫描项目
 */
function doScan(ws: PepacooWorkspace): ProjectScan {
  info(`扫描项目: ${ws.projectPath}`)
  const scan = ws.scanProject()

  ok(`扫描完成`)
  log(`  文件: ${scan.stats.totalFiles}, 目录: ${scan.stats.totalDirs}`)
  log(`  总大小: ${(scan.stats.totalSizeBytes / 1024).toFixed(1)}KB`)

  const topExts = Object.entries(scan.stats.filesByExtension)
    .sort((a, b) => b[1] - a[1])
    .slice(0, 5)
    .map(([ext, count]) => `${ext}(${count})`)
    .join(', ')
  log(`  主要类型: ${topExts}`)
  log(`  关键文件: ${scan.keyFiles.map((f) => f.path).join(', ')}`)

  ws.updateMeta({ alignmentStatus: 'scanned' })
  return scan
}

/**
 * Phase 3: 认知对齐
 * 让 AI 分析项目并生成结构化认知，请用户确认
 */
async function doAlign(
  ws: PepacooWorkspace,
  os: ByteOS,
  coordinator: Agent,
  scan: ProjectScan,
): Promise<string> {
  header('认知对齐')
  ws.updateMeta({ alignmentStatus: 'aligning' })

  const scanPrompt = ws.formatScanForPrompt(scan)

  info('正在分析项目结构...')
  log('')

  const result = await os.run(coordinator, `请分析以下项目，输出结构化认知报告：

${scanPrompt}

请输出以下内容（使用 Markdown 格式）：

## 项目类型
[Web前端/后端/全栈/CLI/库/数据分析/移动端/游戏/DevOps/其他]

## 技术栈
- 语言: ...
- 框架: ...
- 主要依赖: ...
- 构建工具: ...

## 核心模块
[列出 3-8 个核心模块，每个说明名称、路径、职责]

## 架构模式
[MVC/微服务/单体/事件驱动/分层/等]

## 入口文件
[列出主要入口文件及其作用]

## 代码规模评估
[文件数、预估代码行数、复杂度评级]

## 关键发现
[列出 2-5 个值得注意的发现或潜在问题]

请使用 file_read 工具阅读你认为需要深入了解的文件。`, {
    context: { cwd: ws.projectPath },
  })

  const cognition = result.response
  log('')
  divider()
  log(cognition)
  divider()

  // 请用户确认
  log('')
  const approved = await confirm('以上认知是否准确？(输入 n 可以补充修正)')

  let finalCognition = cognition

  if (!approved) {
    const correction = await ask('请输入补充或修正信息: ')
    if (correction) {
      const fixResult = await os.run(coordinator, `用户对项目认知有以下修正/补充：

${correction}

请根据修正信息更新你的项目认知报告。保持相同的 Markdown 格式。之前的认知报告：

${cognition}`)
      finalCognition = fixResult.response
      log('')
      divider()
      log(finalCognition)
      divider()
    }
  }

  // 保存认知
  ws.saveCognition(finalCognition)

  // 提取项目类型和技术栈（简单解析）
  const typeMatch = finalCognition.match(/##\s*项目类型\s*\n+([^\n#]+)/)
  const projectType = typeMatch ? typeMatch[1].trim() : undefined
  const stackMatch = finalCognition.match(/语言:\s*(.+)/)
  const techStack = stackMatch ? stackMatch[1].split(/[,，、]/).map((s) => s.trim()) : undefined

  ws.updateMeta({
    alignmentStatus: 'aligned',
    projectCognition: finalCognition.slice(0, 500),
    projectType,
    techStack,
  })

  ok('认知对齐完成')
  return finalCognition
}

/**
 * Phase 4: 生成目标与架构树
 * 根据用户需求和项目认知创建目标树
 */
async function doPlan(
  ws: PepacooWorkspace,
  os: ByteOS,
  coordinator: Agent,
  cognition: string,
): Promise<SerializedGoalNode[]> {
  header('目标规划')

  const userGoal = await ask('请描述你希望 Agent 帮你完成的任务/目标:\n  ')
  if (!userGoal) {
    warn('未输入目标，跳过规划阶段')
    return []
  }

  log('')
  info('正在生成目标与架构树...')

  const planResult = await os.run(coordinator, `基于项目认知和用户需求，请生成一个分层的目标树。

## 项目认知
${cognition.slice(0, 2000)}

## 用户需求
${userGoal}

请输出以下格式的目标树（JSON 格式，我需要解析它）：

\`\`\`json
[
  {
    "id": "goal-coordinator",
    "agentId": "coordinator",
    "goal": "总目标描述",
    "status": "active",
    "children": [
      {
        "id": "goal-worker-1",
        "agentId": "worker-1",
        "goal": "子目标描述",
        "status": "pending",
        "children": []
      }
    ]
  }
]
\`\`\`

规则：
1. 根节点是 coordinator（已存在），goal 是对用户需求的理解
2. 子节点是需要创建的 worker agent，每个有独立的子任务
3. 最多 3 层深度，每层最多 5 个子节点
4. 每个 goal 必须是具体、可执行的任务描述
5. 只输出 JSON，不要额外解释`, {
    context: { cwd: ws.projectPath },
  })

  // 从 response 中提取 JSON
  let goalTree: SerializedGoalNode[] = []
  const jsonMatch = planResult.response.match(/```json\s*([\s\S]*?)```/)
  if (jsonMatch) {
    try {
      goalTree = JSON.parse(jsonMatch[1])
    } catch (e) {
      warn(`目标树 JSON 解析失败，尝试直接解析`)
      try {
        goalTree = JSON.parse(planResult.response)
      } catch {
        err('无法解析目标树，请手动创建')
        return []
      }
    }
  } else {
    // 尝试直接解析全文
    try {
      goalTree = JSON.parse(planResult.response)
    } catch {
      err('无法解析目标树')
      return []
    }
  }

  // 展示目标树
  log('')
  divider()
  printGoalTree(goalTree, 0)
  divider()

  // 请用户确认
  log('')
  const approved = await confirm('是否同意此目标树？(n = 修改后重新生成)')
  if (!approved) {
    const modify = await ask('请描述你想修改的部分: ')
    if (modify) {
      const fixResult = await os.run(coordinator, `用户对目标树有以下修改意见：

${modify}

原始目标树：
\`\`\`json
${JSON.stringify(goalTree, null, 2)}
\`\`\`

请根据修改意见输出更新后的目标树。保持相同的 JSON 格式，用 \`\`\`json 包裹。`)

      const fixJson = fixResult.response.match(/```json\s*([\s\S]*?)```/)
      if (fixJson) {
        try {
          goalTree = JSON.parse(fixJson[1])
          log('')
          divider()
          printGoalTree(goalTree, 0)
          divider()
        } catch {
          warn('修改后解析失败，使用原始目标树')
        }
      }
    }
  }

  // 保存目标树
  ws.saveGoalTreeSnapshot(goalTree)
  ok('目标树已保存')

  return goalTree
}

function printGoalTree(nodes: SerializedGoalNode[], depth: number): void {
  for (const node of nodes) {
    const indent = '  '.repeat(depth)
    const statusIcon = node.status === 'active' ? '▶' : node.status === 'completed' ? '✓' : '○'
    const statusColor = node.status === 'active' ? C.green : node.status === 'completed' ? C.dim : C.yellow
    log(`${indent}${statusColor}${statusIcon}${C.reset} ${C.bold}${node.agentId}${C.reset}: ${node.goal}`)
    if (node.children?.length) {
      printGoalTree(node.children, depth + 1)
    }
  }
}

/**
 * Phase 5: 部署 — 创建子 Agent 并开始工作
 */
async function doDeploy(
  ws: PepacooWorkspace,
  os: ByteOS,
  coordinator: Agent,
  goalTree: SerializedGoalNode[],
  provider: ModelProvider,
  modelsCfg: ModelsConfig,
  agentsCfg: AgentsConfig,
): Promise<void> {
  header('部署子 Agent')

  // 递归收集所有需要创建的 worker
  interface WorkerTask {
    node: SerializedGoalNode
    parentAgent: Agent
    depth: number
  }

  const tasks: WorkerTask[] = []

  function collectTasks(nodes: SerializedGoalNode[], parent: Agent, depth: number) {
    for (const node of nodes) {
      if (node.agentId === coordinator.id || node.agentId === 'coordinator') {
        // coordinator 已存在，更新目标
        os.manager.createGoal(coordinator.id, node.goal, [])
        if (node.children?.length) {
          collectTasks(node.children, coordinator, depth + 1)
        }
      } else {
        tasks.push({ node, parentAgent: parent, depth })
      }
    }
  }

  collectTasks(goalTree, coordinator, 1)

  if (tasks.length === 0) {
    info('无需创建子 Agent')
    return
  }

  info(`将创建 ${tasks.length} 个子 Agent`)

  // 创建所有 worker
  const workers: { agent: Agent; task: WorkerTask }[] = []

  for (const task of tasks) {
    const workerPrompt = agentsCfg.workerPromptTemplate
      .replace('{{name}}', task.node.agentId)
      .replace('{{task}}', task.node.goal)

    // 获取该深度的模型
    const depthModel = modelsCfg.depthOverrides?.[task.depth]
    const workerModel = depthModel ?? modelsCfg.worker

    const workerProvider = createProviderByName(ws, workerModel.provider)

    const child = task.parentAgent.createChild({
      name: task.node.agentId,
      role: 'worker',
      systemPrompt: workerPrompt + `\n\n项目路径: ${ws.projectPath}`,
      provider: workerProvider,
      model: workerModel.model,
      builtinTools: true,
      watchTags: [...agentsCfg.defaultWatchTags],
      autonomous: agentsCfg.autonomousDefaults,
    })

    os.runtime.registerAgent(child)
    os.manager.register(child.id, child.role, child.getDepth())
    os.manager.createGoal(child.id, task.node.goal, [], task.parentAgent.id)

    workers.push({ agent: child, task })
    ok(`创建 ${C.bold}${task.node.agentId}${C.reset} (depth=${task.depth}): ${task.node.goal.slice(0, 60)}...`)
  }

  ws.updateMeta({ alignmentStatus: 'deployed' })

  divider()
  log('')
  info('Agent 树结构:')
  printAgentTree(coordinator, 0)
  log('')

  // 询问是否立即执行
  const startNow = await confirm('是否立即开始执行任务？')
  if (!startNow) {
    info('子 Agent 已创建但未启动，可通过 /start 命令手动启动')
    return
  }

  // 并行执行所有顶层 worker
  const topLevelWorkers = workers.filter((w) => w.task.parentAgent === coordinator)

  header('执行任务')
  info(`并行启动 ${topLevelWorkers.length} 个顶层 worker...\n`)

  const cognition = ws.loadCognition() ?? ''
  const results = await Promise.allSettled(
    topLevelWorkers.map((w) =>
      os.run(w.agent, `请执行你的任务：

${w.task.node.goal}

项目认知背景：
${cognition.slice(0, 1000)}

使用工具（file_read/bash 等）来完成工作。完成后输出简洁的结果报告。`, {
        context: { cwd: ws.projectPath },
      }),
    ),
  )

  log('')
  divider()
  info('执行结果:')

  for (let i = 0; i < topLevelWorkers.length; i++) {
    const w = topLevelWorkers[i]
    const r = results[i]
    if (r.status === 'fulfilled') {
      ok(`${C.bold}${w.agent.name}${C.reset}: ${r.value.response.slice(0, 120)}...`)
      log(`  ${C.dim}Tokens: ${r.value.totalTokens}, 轮次: ${r.value.turns}${C.reset}`)
    } else {
      err(`${C.bold}${w.agent.name}${C.reset}: ${r.reason}`)
    }
  }

  // 保存最终目标树快照
  const finalGoals = serializeGoalTree(coordinator, os)
  ws.saveGoalTreeSnapshot(finalGoals)

  log('')
  ok('任务执行完成')
  log(`  计费报告: ${os.printUsageReport().split('\n').join('\n  ')}`)
}

/** 递归打印 agent 树 */
function printAgentTree(agent: Agent, depth: number): void {
  const indent = '  '.repeat(depth)
  const icon = agent.role === 'coordinator' ? '🎯' : '🔧'
  const status = agent.status === 'idle' ? C.green + 'idle' : agent.status === 'running' ? C.yellow + 'running' : C.dim + agent.status
  log(`${indent}${icon} ${C.bold}${agent.name}${C.reset} (${status}${C.reset}) [${[...agent.watchTags].slice(0, 3).join(',')}]`)
  for (const child of agent.children) {
    printAgentTree(child, depth + 1)
  }
}

/** 序列化 goal tree */
function serializeGoalTree(agent: Agent, os: ByteOS): SerializedGoalNode[] {
  const goal = os.manager.getGoal(agent.id)
  const node: SerializedGoalNode = {
    id: goal?.id ?? `goal-${agent.id}`,
    agentId: agent.id,
    goal: goal?.goal ?? agent.name,
    status: goal?.status ?? 'pending',
    children: agent.children.map((c) => serializeGoalTree(c, os)[0]).filter(Boolean),
  }
  return [node]
}

// ---- 根据名称创建 provider 的缓存 ----
const providerCache = new Map<string, ModelProvider>()

function createProviderByName(ws: PepacooWorkspace, name: string): ModelProvider {
  if (providerCache.has(name)) return providerCache.get(name)!
  const providersCfg = ws.getProviders()
  const p = createProvider(providersCfg, name)
  providerCache.set(name, p)
  return p
}

// ============================================================
//  交互式 REPL（部署后进入）
// ============================================================

async function interactiveLoop(
  ws: PepacooWorkspace,
  os: ByteOS,
  coordinator: Agent,
): Promise<void> {
  header('交互模式')
  info('输入自然语言与协调者对话，或使用斜杠命令')
  log(`  ${C.dim}/tree${C.reset}        — 查看 Agent 树`)
  log(`  ${C.dim}/goals${C.reset}       — 查看目标树`)
  log(`  ${C.dim}/status${C.reset}      — 运行时状态`)
  log(`  ${C.dim}/wake <id>${C.reset}   — 唤醒 Agent`)
  log(`  ${C.dim}/recycle <id>${C.reset} — 回收子 Agent`)
  log(`  ${C.dim}/usage${C.reset}       — 计费报告`)
  log(`  ${C.dim}/exit${C.reset}        — 退出`)
  log('')

  const promptText = () => `${C.cyan}pepacoo${C.reset} ${C.dim}>${C.reset} `

  while (true) {
    const input = await new Promise<string>((res) => rl.question(promptText(), res))
    const trimmed = input.trim()
    if (!trimmed) continue

    if (trimmed.startsWith('/')) {
      const [cmd, ...args] = trimmed.slice(1).split(/\s+/)

      switch (cmd) {
        case 'exit':
        case 'quit':
        case 'q':
          // 保存状态
          ws.updateMeta({ lastActiveAt: new Date().toISOString() })
          ok('状态已保存，再见！')
          rl.close()
          process.exit(0)
          break

        case 'tree':
          printAgentTree(coordinator, 0)
          break

        case 'goals': {
          const goals = os.manager.getGoalTree()
          if (goals.length) {
            printGoalTree(
              goals.map((g) => serializeGoalNodeFromGoal(g)),
              0,
            )
          } else {
            info('目标树为空')
          }
          break
        }

        case 'status': {
          const s = os.getRuntimeStatus()
          log(`  总 Agent: ${s.totalAgents}, Idle: ${s.idleAgents}, Running: ${s.runningAgents}`)
          log(`  自主: ${s.autonomousAgents}, 信号: sent=${s.signalBusStats.totalSent} delivered=${s.signalBusStats.totalDelivered}`)
          break
        }

        case 'wake':
          if (args[0]) {
            const woken = await os.wakeAgent(args[0], 'user', args.slice(1).join(' ') || 'manual')
            log(woken ? `  已唤醒 ${args[0]}` : `  唤醒失败`)
          } else {
            warn('用法: /wake <agentId>')
          }
          break

        case 'recycle':
          if (args[0]) {
            const mem = os.recycleAgent(coordinator.id, args[0])
            if (mem) {
              ok(`已回收 ${mem.agentName}`)
              log(`  摘要: ${mem.summary.slice(0, 120)}...`)
              ws.saveArchive(mem.agentId, mem)
            } else {
              err('回收失败')
            }
          } else {
            warn('用法: /recycle <agentId>')
          }
          break

        case 'usage':
          log(os.printUsageReport())
          break

        default:
          warn(`未知命令: /${cmd}`)
      }
    } else {
      // 自然语言对话
      try {
        const result = await os.run(coordinator, trimmed, {
          context: { cwd: ws.projectPath },
        })
        log('')
        log(result.response)
        log(`${C.dim}  [tokens: ${result.totalTokens}, turns: ${result.turns}]${C.reset}`)
      } catch (e) {
        err(`${e instanceof Error ? e.message : String(e)}`)
      }
    }
    log('')
  }
}

function serializeGoalNodeFromGoal(goal: import('./index.ts').GoalNode): SerializedGoalNode {
  return {
    id: goal.id,
    agentId: goal.agentId,
    goal: goal.goal,
    status: goal.status,
    children: goal.children.map(serializeGoalNodeFromGoal),
  }
}

// ============================================================
//  完整流程编排: start = init → scan → align → plan → deploy → repl
// ============================================================

async function fullStart(projectPath: string, opts: { provider?: string; model?: string; apiKey?: string }): Promise<void> {
  header('PEPACOO — 项目托管 Agent 系统')

  // ---- Phase 1: Init ----
  const ws = doInit(projectPath, opts)
  const meta = ws.getMeta()

  // ---- 创建 ByteOS ----
  const modelsCfg = ws.getModels()
  const providersCfg = ws.getProviders()
  const permsCfg = ws.getPermissions()
  const agentsCfg = ws.getAgentsConfig()

  const os = new ByteOS({
    autoApproveLevel: permsCfg.autoApproveLevel,
    onEvent: (event) => {
      if (event.type === 'progress' && event.content) {
        process.stdout.write(event.content)
      }
    },
    onPermissionRequest: (req) => {
      warn(`权限请求: [${req.risk}] ${req.description}`)
      // 交互式模式下这里会挂起，demo 先自动放行
      os.permissionGuard.resolve(req.id, { action: 'allow' })
    },
  })

  // 创建默认 provider
  const defaultProviderName = opts.provider ?? providersCfg.default
  let defaultProvider: ModelProvider

  try {
    defaultProvider = createProviderByName(ws, defaultProviderName)
    ok(`Provider: ${defaultProviderName}`)
  } catch (e) {
    err(`Provider 初始化失败: ${e instanceof Error ? e.message : String(e)}`)
    const apiKey = await ask(`请输入 ${defaultProviderName} 的 API Key: `)
    if (!apiKey) {
      err('无法继续，需要 API Key')
      process.exit(1)
    }
    // 更新配置
    providersCfg.providers[defaultProviderName] = {
      type: defaultProviderName as 'openrouter',
      apiKey,
    }
    ws.writeConfig('providers.json', providersCfg)
    defaultProvider = createProviderByName(ws, defaultProviderName)
    ok(`Provider ${defaultProviderName} 已配置`)
  }

  // ---- 创建顶层协调者 ----
  const coordModel = opts.model ?? modelsCfg.coordinator.model
  const coordinator = os.createAgent({
    name: `${meta.projectName}-coordinator`,
    role: 'coordinator',
    systemPrompt: agentsCfg.coordinatorPrompt,
    provider: defaultProvider,
    model: coordModel,
    builtinTools: true,
    watchTags: ['agent:wake', 'fs:watch', 'project:analyze'],
  })

  ws.updateMeta({ coordinatorId: coordinator.id })
  ok(`顶层 Agent: ${coordinator.name} (${coordModel})`)

  // ---- Phase 2: Scan ----
  divider()
  const scan = doScan(ws)

  // ---- Phase 3: Align ----
  const cognition = await doAlign(ws, os, coordinator, scan)

  // ---- Phase 4: Plan ----
  const goalTree = await doPlan(ws, os, coordinator, cognition)

  // ---- Phase 5: Deploy ----
  if (goalTree.length > 0) {
    await doDeploy(ws, os, coordinator, goalTree, defaultProvider, modelsCfg, agentsCfg)
  }

  // ---- Phase 6: Interactive REPL ----
  await interactiveLoop(ws, os, coordinator)
}

// ============================================================
//  恢复流程
// ============================================================

async function resume(projectPath: string): Promise<void> {
  const ws = new PepacooWorkspace(projectPath)
  if (!ws.isInitialized()) {
    err(`${projectPath} 没有 .pepacoo/ 目录，请先运行 pepacoo init`)
    process.exit(1)
  }

  const meta = ws.getMeta()
  header(`PEPACOO — 恢复: ${meta.projectName}`)
  info(`状态: ${meta.alignmentStatus}`)
  info(`上次活跃: ${meta.lastActiveAt}`)

  const modelsCfg = ws.getModels()
  const providersCfg = ws.getProviders()
  const permsCfg = ws.getPermissions()
  const agentsCfg = ws.getAgentsConfig()

  const os = new ByteOS({
    autoApproveLevel: permsCfg.autoApproveLevel,
    onEvent: (event) => {
      if (event.type === 'progress' && event.content) {
        process.stdout.write(event.content)
      }
    },
    onPermissionRequest: (req) => {
      warn(`权限请求: [${req.risk}] ${req.description}`)
      os.permissionGuard.resolve(req.id, { action: 'allow' })
    },
  })

  const defaultProvider = createProviderByName(ws, providersCfg.default)

  // 重建协调者
  const coordinator = os.createAgent({
    name: `${meta.projectName}-coordinator`,
    role: 'coordinator',
    systemPrompt: agentsCfg.coordinatorPrompt,
    provider: defaultProvider,
    model: modelsCfg.coordinator.model,
    builtinTools: true,
    watchTags: ['agent:wake', 'fs:watch', 'project:analyze'],
  })

  // 注入历史认知
  const cognition = ws.loadCognition()
  if (cognition) {
    coordinator.messages.push({
      role: 'system',
      content: `[历史项目认知]\n${cognition}`,
    })
    ok('已加载历史认知')
  }

  // 加载目标树快照
  const savedGoals = ws.loadLatestGoalTree()
  if (savedGoals) {
    ok(`已加载目标树 (${countGoalNodes(savedGoals)} 个节点)`)
  }

  ws.updateMeta({ coordinatorId: coordinator.id })

  // 根据状态决定从哪里开始
  if (meta.alignmentStatus === 'not_started' || meta.alignmentStatus === 'scanning') {
    const scan = doScan(ws)
    const cog = await doAlign(ws, os, coordinator, scan)
    const goalTree = await doPlan(ws, os, coordinator, cog)
    if (goalTree.length) {
      await doDeploy(ws, os, coordinator, goalTree, defaultProvider, modelsCfg, agentsCfg)
    }
  } else if (meta.alignmentStatus === 'scanned') {
    const scan = ws.readConfig<ProjectScan>('cognition/latest-scan.json')
    const cog = await doAlign(ws, os, coordinator, scan)
    const goalTree = await doPlan(ws, os, coordinator, cog)
    if (goalTree.length) {
      await doDeploy(ws, os, coordinator, goalTree, defaultProvider, modelsCfg, agentsCfg)
    }
  } else if (meta.alignmentStatus === 'aligned') {
    const goalTree = await doPlan(ws, os, coordinator, cognition ?? '')
    if (goalTree.length) {
      await doDeploy(ws, os, coordinator, goalTree, defaultProvider, modelsCfg, agentsCfg)
    }
  }

  // 进入交互式 REPL
  await interactiveLoop(ws, os, coordinator)
}

function countGoalNodes(nodes: SerializedGoalNode[]): number {
  return nodes.reduce((acc, n) => acc + 1 + countGoalNodes(n.children ?? []), 0)
}

// ============================================================
//  状态查看
// ============================================================

function showStatus(projectPath: string): void {
  const ws = new PepacooWorkspace(projectPath)
  if (!ws.isInitialized()) {
    err(`${projectPath} 没有 .pepacoo/ 目录`)
    process.exit(1)
  }

  const meta = ws.getMeta()
  header(`PEPACOO 工作区: ${meta.projectName}`)
  log(`  路径:     ${meta.projectPath}`)
  log(`  创建:     ${meta.createdAt}`)
  log(`  活跃:     ${meta.lastActiveAt}`)
  log(`  状态:     ${meta.alignmentStatus}`)
  if (meta.projectType) log(`  类型:     ${meta.projectType}`)
  if (meta.techStack) log(`  技术栈:   ${meta.techStack.join(', ')}`)
  if (meta.coordinatorId) log(`  协调者ID: ${meta.coordinatorId}`)
  log('')

  // 显示目标树
  const goals = ws.loadLatestGoalTree()
  if (goals) {
    info('目标树:')
    printGoalTree(goals, 1)
  }
}

// ============================================================
//  CLI 入口
// ============================================================

async function main() {
  const args = process.argv.slice(2)
  const command = args[0] ?? 'start'

  initRL()

  // 解析命名参数
  const namedArgs: Record<string, string> = {}
  const positional: string[] = []
  for (let i = 1; i < args.length; i++) {
    if (args[i].startsWith('--') && i + 1 < args.length) {
      namedArgs[args[i].slice(2)] = args[i + 1]
      i++
    } else {
      positional.push(args[i])
    }
  }

  const projectPath = resolve(positional[0] ?? '.')

  switch (command) {
    case 'init':
      doInit(projectPath, {
        provider: namedArgs.provider,
        model: namedArgs.model,
        apiKey: namedArgs.key ?? namedArgs.apiKey,
      })
      rl.close()
      break

    case 'start':
      await fullStart(projectPath, {
        provider: namedArgs.provider,
        model: namedArgs.model,
        apiKey: namedArgs.key ?? namedArgs.apiKey,
      })
      break

    case 'resume':
      await resume(projectPath)
      break

    case 'status':
      showStatus(projectPath)
      rl.close()
      break

    case 'help':
      log(`
${C.bold}Pepacoo — 项目托管 Agent 系统${C.reset}

${C.bold}命令:${C.reset}
  ${C.cyan}init${C.reset} [path] [--provider xx] [--model xx] [--key xx]
      初始化 .pepacoo/ 工作区，生成配置文件

  ${C.cyan}start${C.reset} [path] [--provider xx] [--model xx] [--key xx]
      完整流程: init → 扫描 → 认知对齐 → 规划 → 部署 → 交互

  ${C.cyan}resume${C.reset} [path]
      恢复已有工作区，从上次中断处继续

  ${C.cyan}status${C.reset} [path]
      查看工作区状态和目标树

${C.bold}示例:${C.reset}
  node --experimental-strip-types src/pepacoo.ts start D:\\my-project --provider openrouter --key sk-xxx
  node --experimental-strip-types src/pepacoo.ts resume .
  node --experimental-strip-types src/pepacoo.ts status D:\\my-project

${C.bold}配置文件 (.pepacoo/):${C.reset}
  models.json       各级默认模型（coordinator/worker/scanner + 深度/标签覆盖）
  providers.json    Provider 凭证（支持 \${ENV_VAR} 引用环境变量）
  agents.json       Agent 行为（prompt模板/watchTags/自主模式/深度限制）
  permissions.json  权限策略（风险等级/工具黑白名单/危险命令模式）
  scan.json         扫描规则（忽略目录/文件/关键文件列表/大文件阈值）
`)
      rl.close()
      break

    default:
      err(`未知命令: ${command}，使用 help 查看帮助`)
      rl.close()
      process.exit(1)
  }
}

main().catch((e) => {
  err(`致命错误: ${e instanceof Error ? e.message : String(e)}`)
  process.exit(1)
})
