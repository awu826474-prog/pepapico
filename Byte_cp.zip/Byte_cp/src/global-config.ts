/**
 * PepaPico 全局配置管理
 *
 * 全局配置目录（默认 ~/.pepapico）：
 *   config.json          — 全局设置
 *   templates/           — 项目配置模版（含 provider/key 等）
 *     default/           — 默认模版
 *       providers.json
 *       models.json
 *       agents.json
 *       permissions.json
 *       scan.json
 *
 * 全局配置位置管理：
 *   - 指针文件 ~/.pepapico-pointer 存储实际路径
 *   - 可通过 relocate 修改指向
 *   - 可通过 migrate 移动配置到新位置
 *   - 可通过 pack / unpack 打包导入导出
 */

import { existsSync, mkdirSync, writeFileSync, readFileSync, readdirSync, statSync, cpSync, rmSync, renameSync } from 'node:fs'
import { join, resolve, basename } from 'node:path'
import { homedir } from 'node:os'
import type { ProvidersConfig, ModelsConfig, AgentsConfig, PermissionsConfig, ScanConfig } from './workspace.ts'

// ============================================================
//  Types
// ============================================================

/** 全局配置 config.json */
export interface GlobalConfig {
  version: string
  /** 实际全局目录路径（冗余，用于自检） */
  globalDir: string
  /** 默认模版名 */
  defaultTemplate: string
  /** 最近打开的项目 */
  recentProjects: RecentProject[]
  createdAt: string
  updatedAt: string
}

export interface RecentProject {
  path: string
  name: string
  lastOpened: string
}

/** 一个项目配置模版 */
export interface ProjectTemplate {
  name: string
  providers: ProvidersConfig
  models: ModelsConfig
  agents?: AgentsConfig
  permissions?: PermissionsConfig
  scan?: ScanConfig
  description?: string
  createdAt: string
  updatedAt: string
}

/** 打包格式 — 把整个全局配置序列化为单个 JSON */
export interface PackedConfig {
  version: string
  packedAt: string
  globalConfig: GlobalConfig
  templates: Record<string, ProjectTemplate>
}

// ============================================================
//  指针文件 — 定位全局配置目录
// ============================================================

const POINTER_FILE = '.pepapico-pointer'
const DEFAULT_DIR_NAME = '.pepapico'
const GLOBAL_CONFIG_FILE = 'config.json'
const TEMPLATES_DIR = 'templates'

/** 获取指针文件路径 */
function getPointerPath(): string {
  return join(homedir(), POINTER_FILE)
}

/** 获取默认全局配置目录 */
function getDefaultGlobalDir(): string {
  return join(homedir(), DEFAULT_DIR_NAME)
}

/**
 * 解析实际全局配置目录
 * 优先级：环境变量 PEPAPICO_HOME > 指针文件 > 默认 ~/.pepapico
 */
export function resolveGlobalDir(): string {
  // 1. 环境变量
  if (process.env.PEPAPICO_HOME) {
    return resolve(process.env.PEPAPICO_HOME)
  }
  // 2. 指针文件
  const pointerPath = getPointerPath()
  if (existsSync(pointerPath)) {
    const target = readFileSync(pointerPath, 'utf-8').trim()
    if (target && existsSync(target)) {
      return resolve(target)
    }
  }
  // 3. 默认
  return getDefaultGlobalDir()
}

/** 写入指针文件 */
function writePointer(targetDir: string): void {
  writeFileSync(getPointerPath(), resolve(targetDir), 'utf-8')
}

// ============================================================
//  初始化
// ============================================================

/** 默认模版 providers */
const DEFAULT_TEMPLATE_PROVIDERS: ProvidersConfig = {
  default: 'openrouter',
  providers: {
    openrouter: {
      type: 'openrouter',
      apiKey: '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',
    },
  },
}

/** 默认模版 models */
const DEFAULT_TEMPLATE_MODELS: ModelsConfig = {
  coordinator: { provider: 'openrouter', model: 'anthropic/claude-sonnet-4-5' },
  worker: { provider: 'openrouter', model: 'anthropic/claude-sonnet-4-5' },
  scanner: { provider: 'openrouter', model: 'anthropic/claude-sonnet-4-5' },
}

/**
 * 初始化全局配置目录（如果不存在）
 * 返回全局目录路径
 */
export function initGlobalConfig(): string {
  const dir = resolveGlobalDir()
  const configPath = join(dir, GLOBAL_CONFIG_FILE)

  if (existsSync(configPath)) {
    return dir
  }

  // 创建目录结构
  mkdirSync(dir, { recursive: true })
  mkdirSync(join(dir, TEMPLATES_DIR), { recursive: true })

  // 写入默认 config.json
  const config: GlobalConfig = {
    version: '0.1.0',
    globalDir: dir,
    defaultTemplate: 'default',
    recentProjects: [],
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  }
  writeJSON(configPath, config)

  // 创建默认模版
  const defaultTemplate: ProjectTemplate = {
    name: 'default',
    providers: DEFAULT_TEMPLATE_PROVIDERS,
    models: DEFAULT_TEMPLATE_MODELS,
    description: '默认模版 — OpenRouter',
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  }
  saveTemplate(defaultTemplate)

  // 写指针文件（方便未来迁移）
  writePointer(dir)

  return dir
}

// ============================================================
//  全局配置读写
// ============================================================

export function readGlobalConfig(): GlobalConfig {
  const dir = resolveGlobalDir()
  return readJSON<GlobalConfig>(join(dir, GLOBAL_CONFIG_FILE))
}

export function writeGlobalConfig(config: GlobalConfig): void {
  const dir = resolveGlobalDir()
  config.updatedAt = new Date().toISOString()
  writeJSON(join(dir, GLOBAL_CONFIG_FILE), config)
}

export function updateGlobalConfig(patch: Partial<GlobalConfig>): GlobalConfig {
  const config = readGlobalConfig()
  const updated = { ...config, ...patch, updatedAt: new Date().toISOString() }
  writeGlobalConfig(updated)
  return updated
}

/** 记录最近打开的项目 */
export function addRecentProject(projectPath: string, projectName: string): void {
  const config = readGlobalConfig()
  const entry: RecentProject = {
    path: resolve(projectPath),
    name: projectName,
    lastOpened: new Date().toISOString(),
  }
  // 去重 + 置顶
  config.recentProjects = [
    entry,
    ...config.recentProjects.filter((p) => p.path !== entry.path),
  ].slice(0, 20)
  writeGlobalConfig(config)
}

// ============================================================
//  模版 CRUD
// ============================================================

function getTemplateDir(name: string): string {
  return join(resolveGlobalDir(), TEMPLATES_DIR, name)
}

/** 列出所有模版名 */
export function listTemplates(): string[] {
  const dir = join(resolveGlobalDir(), TEMPLATES_DIR)
  if (!existsSync(dir)) return []
  return readdirSync(dir, { withFileTypes: true })
    .filter((d) => d.isDirectory())
    .map((d) => d.name)
}

/** 获取一个模版 */
export function getTemplate(name: string): ProjectTemplate | null {
  const dir = getTemplateDir(name)
  const metaPath = join(dir, 'template.json')
  if (!existsSync(metaPath)) return null
  return readJSON<ProjectTemplate>(metaPath)
}

/** 保存/更新一个模版 */
export function saveTemplate(template: ProjectTemplate): void {
  const dir = getTemplateDir(template.name)
  mkdirSync(dir, { recursive: true })
  template.updatedAt = new Date().toISOString()
  writeJSON(join(dir, 'template.json'), template)

  // 同时写出各个配置文件（方便手动查看/编辑）
  writeJSON(join(dir, 'providers.json'), template.providers)
  writeJSON(join(dir, 'models.json'), template.models)
  if (template.agents) writeJSON(join(dir, 'agents.json'), template.agents)
  if (template.permissions) writeJSON(join(dir, 'permissions.json'), template.permissions)
  if (template.scan) writeJSON(join(dir, 'scan.json'), template.scan)
}

/** 删除模版 */
export function deleteTemplate(name: string): boolean {
  const dir = getTemplateDir(name)
  if (!existsSync(dir)) return false
  rmSync(dir, { recursive: true, force: true })
  return true
}

/** 从当前项目的 .pepapico/ 导出为模版 */
export function exportProjectAsTemplate(
  projectPepapicDir: string,
  templateName: string,
  description?: string,
): ProjectTemplate {
  const providers = readJSONSafe<ProvidersConfig>(join(projectPepapicDir, 'providers.json'), null)
  const models = readJSONSafe<ModelsConfig>(join(projectPepapicDir, 'models.json'), null)
  const agents = readJSONSafe<AgentsConfig>(join(projectPepapicDir, 'agents.json'), undefined)
  const permissions = readJSONSafe<PermissionsConfig>(join(projectPepapicDir, 'permissions.json'), undefined)
  const scan = readJSONSafe<ScanConfig>(join(projectPepapicDir, 'scan.json'), undefined)

  if (!providers || !models) {
    throw new Error('项目缺少 providers.json 或 models.json，无法导出为模版')
  }

  const template: ProjectTemplate = {
    name: templateName,
    providers,
    models,
    agents,
    permissions,
    scan,
    description,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  }
  saveTemplate(template)
  return template
}

/** 将模版应用到项目的 .pepapico/ */
export function applyTemplateToProject(
  templateName: string,
  projectPepapicDir: string,
): boolean {
  const template = getTemplate(templateName)
  if (!template) return false

  writeJSON(join(projectPepapicDir, 'providers.json'), template.providers)
  writeJSON(join(projectPepapicDir, 'models.json'), template.models)
  if (template.agents) writeJSON(join(projectPepapicDir, 'agents.json'), template.agents)
  if (template.permissions) writeJSON(join(projectPepapicDir, 'permissions.json'), template.permissions)
  if (template.scan) writeJSON(join(projectPepapicDir, 'scan.json'), template.scan)

  return true
}

// ============================================================
//  全局配置位置管理
// ============================================================

/**
 * 修改定向地址 — 更新指针文件指向新路径
 * 注意：这只改指向，不移动文件。如果新路径已存在配置则直接使用。
 */
export function relocate(newDir: string): string {
  const absDir = resolve(newDir)
  writePointer(absDir)
  // 如果新位置没有初始化过，初始化
  if (!existsSync(join(absDir, GLOBAL_CONFIG_FILE))) {
    // 临时覆盖解析为新路径
    const saved = process.env.PEPAPICO_HOME
    process.env.PEPAPICO_HOME = absDir
    initGlobalConfig()
    if (saved !== undefined) process.env.PEPAPICO_HOME = saved
    else delete process.env.PEPAPICO_HOME
  }
  return absDir
}

/**
 * 配置移动 — 将当前全局配置整体搬迁到新路径
 * 1. 复制当前目录到新位置
 * 2. 更新指针文件
 * 3. 更新 config.json 中的 globalDir
 */
export function migrate(newDir: string): string {
  const currentDir = resolveGlobalDir()
  const absNew = resolve(newDir)

  if (currentDir === absNew) {
    throw new Error('新路径与当前路径相同')
  }

  // 复制整个目录
  mkdirSync(absNew, { recursive: true })
  cpSync(currentDir, absNew, { recursive: true })

  // 更新指针
  writePointer(absNew)

  // 更新 config.json 中的 globalDir
  const config = readJSON<GlobalConfig>(join(absNew, GLOBAL_CONFIG_FILE))
  config.globalDir = absNew
  config.updatedAt = new Date().toISOString()
  writeJSON(join(absNew, GLOBAL_CONFIG_FILE), config)

  return absNew
}

/**
 * 配置打包 — 导出为单个 JSON 文件
 */
export function packConfig(outputPath: string): void {
  const config = readGlobalConfig()
  const templateNames = listTemplates()
  const templates: Record<string, ProjectTemplate> = {}

  for (const name of templateNames) {
    const t = getTemplate(name)
    if (t) templates[name] = t
  }

  const packed: PackedConfig = {
    version: '0.1.0',
    packedAt: new Date().toISOString(),
    globalConfig: config,
    templates,
  }

  writeJSON(outputPath, packed)
}

/**
 * 配置解包 — 从打包文件恢复
 * 会覆盖当前全局配置和模版
 */
export function unpackConfig(inputPath: string): void {
  const packed = readJSON<PackedConfig>(inputPath)
  const dir = resolveGlobalDir()

  // 恢复 config.json（保留当前 globalDir）
  packed.globalConfig.globalDir = dir
  packed.globalConfig.updatedAt = new Date().toISOString()
  writeJSON(join(dir, GLOBAL_CONFIG_FILE), packed.globalConfig)

  // 恢复模版
  for (const [_name, template] of Object.entries(packed.templates)) {
    saveTemplate(template)
  }
}

// ============================================================
//  工具函数
// ============================================================

function writeJSON(path: string, data: unknown): void {
  writeFileSync(path, JSON.stringify(data, null, 2), 'utf-8')
}

function readJSON<T>(path: string): T {
  return JSON.parse(readFileSync(path, 'utf-8')) as T
}

function readJSONSafe<T>(path: string, fallback: T): T {
  try {
    if (!existsSync(path)) return fallback
    return readJSON<T>(path)
  } catch {
    return fallback
  }
}

// ============================================================
//  获取全局配置摘要（用于 CLI 显示）
// ============================================================

export function getGlobalSummary(): {
  globalDir: string
  templateCount: number
  templates: string[]
  recentProjects: RecentProject[]
  defaultTemplate: string
} {
  const dir = resolveGlobalDir()
  if (!existsSync(join(dir, GLOBAL_CONFIG_FILE))) {
    return { globalDir: dir, templateCount: 0, templates: [], recentProjects: [], defaultTemplate: 'default' }
  }
  const config = readGlobalConfig()
  const templates = listTemplates()
  return {
    globalDir: dir,
    templateCount: templates.length,
    templates,
    recentProjects: config.recentProjects,
    defaultTemplate: config.defaultTemplate,
  }
}
