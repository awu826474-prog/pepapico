#!/usr/bin/env node
/**
 * PepaPico — 项目托管 Agent 系统
 *
 * 启动:
 *   npm run pico                    ← 托管当前目录
 *   npm run pico -- D:\my-project   ← 托管指定项目
 *
 * 终端内命令管理 Provider、切换项目、操控 Agent 树。
 */

import * as readline from 'node:readline'
import { resolve, basename } from 'node:path'
import { existsSync, readFileSync } from 'node:fs'

import {
  PepacooWorkspace,
} from './workspace.ts'
import type {
  ModelsConfig,
  ProvidersConfig,
  AgentsConfig,
  ProjectScan,
  WorkspaceMeta,
  SerializedGoalNode,
} from './workspace.ts'

import {
  ByteOS,
  Agent,
  createOpenRouter,
  createCopilot,
  createSubAgentTool,
  registerProvider,
} from './index.ts'
import { authenticateCopilot } from './provider/copilot.ts'
import type {
  AgentLoopResult,
  ModelProvider,
  PermissionRequest,
} from './index.ts'

import {
  initGlobalConfig,
  resolveGlobalDir,
  readGlobalConfig,
  updateGlobalConfig,
  addRecentProject,
  listTemplates,
  getTemplate,
  saveTemplate,
  deleteTemplate,
  exportProjectAsTemplate,
  applyTemplateToProject,
  relocate,
  migrate,
  packConfig,
  unpackConfig,
  getGlobalSummary,
} from './global-config.ts'
import type { ProjectTemplate } from './global-config.ts'

// ============================================================
//  ANSI
// ============================================================

const C = {
  reset: '\x1b[0m',
  bold: '\x1b[1m',
  dim: '\x1b[2m',
  red: '\x1b[31m',
  green: '\x1b[32m',
  yellow: '\x1b[33m',
  blue: '\x1b[34m',
  magenta: '\x1b[35m',
  cyan: '\x1b[36m',
  white: '\x1b[37m',
  pink: '\x1b[38;5;218m',
  hotpink: '\x1b[38;5;205m',
  bgBlue: '\x1b[44m',
  bgGreen: '\x1b[42m',
  bgYellow: '\x1b[43m',
  bgMagenta: '\x1b[45m',
  darkGray: '\x1b[1;90m',
  gold: '\x1b[38;5;220m',
  brightRed: '\x1b[38;5;196m',
}

function log(msg: string) { console.log(msg) }
function info(msg: string) { log(`${C.cyan}ℹ${C.reset} ${msg}`) }
function ok(msg: string) { log(`${C.green}✓${C.reset} ${msg}`) }
function warn(msg: string) { log(`${C.yellow}⚠${C.reset} ${msg}`) }
function err(msg: string) { log(`${C.red}✗${C.reset} ${msg}`) }
function header(msg: string) { log(`\n${C.bgBlue}${C.white}${C.bold} ${msg} ${C.reset}\n`) }
function divider() { log(`${C.dim}${'─'.repeat(60)}${C.reset}`) }
/** Agent Manager 日志（前缀 [MGR]）*/
function mgrLog(msg: string) { log(`${C.dim}[MGR]${C.reset} ${msg}`) }

// ============================================================
//  Provider 模型建议
// ============================================================

const MODEL_SUGGESTIONS: Record<string, string[]> = {
  copilot: ['gpt-4o', 'gpt-4o-mini', 'claude-sonnet-4', 'o3-mini', 'o1-mini'],
  openrouter: ['anthropic/claude-sonnet-4-5', 'openai/gpt-4o', 'google/gemini-2.5-flash', 'meta-llama/llama-3.1-70b-instruct', 'deepseek/deepseek-chat-v3-0324'],
}

function suggestModels(providerName: string): string[] {
  for (const [key, models] of Object.entries(MODEL_SUGGESTIONS)) {
    if (providerName.toLowerCase().includes(key)) return models
  }
  return ['gpt-4o', 'claude-sonnet-4']
}

// ============================================================
//  带模型重试的 os.run 包装
// ============================================================

async function runWithRetry(
  os: ByteOS, agent: Agent, message: string,
  options?: { context?: string },
): Promise<import('./index.ts').AgentLoopResult> {
  while (true) {
    try {
      return await os.run(agent, message, options)
    } catch (e) {
      const msg = e instanceof Error ? e.message : String(e)
      // 模型不支持 / 400 错误 → 让用户换模型
      if (msg.includes('model_not_supported') || msg.includes('does not exist') ||
          (msg.includes('400') && msg.includes('model'))) {
        err(`模型错误: ${msg}`)
        info(`当前模型: ${C.bold}${agent.model}${C.reset}`)
        const suggestions = suggestModels(session?.defaultProviderName ?? '')
        log(`  ${C.dim}建议模型: ${suggestions.join(', ')}${C.reset}`)
        const newModel = await ask('请输入新的模型名称: ')
        if (!newModel) throw new Error('用户取消模型选择')
        agent.model = newModel.trim()
        // 同步更新配置
        if (session) {
          const modelsCfg = session.ws.getModels()
          modelsCfg.coordinator = { ...modelsCfg.coordinator, model: agent.model }
          modelsCfg.worker = { ...modelsCfg.worker, model: agent.model }
          modelsCfg.scanner = { ...modelsCfg.scanner, model: agent.model }
          session.ws.writeConfig('models.json', modelsCfg)
        }
        ok(`模型已切换为: ${agent.model}，重试中...`)
        continue
      }
      // 其他 API 错误也不致命 — 允许重试
      if (msg.includes('API error') || msg.includes('fetch failed') || msg.includes('ECONNREFUSED')) {
        err(`API 错误: ${msg}`)
        const retry = await confirm('是否重试？')
        if (retry) continue
      }
      throw e
    }
  }
}

// ============================================================
//  启动画面 — 墨镜小猪佩奇 + PepaPico 大字
// ============================================================

function showSplash() {
  // jp2a ASCII pig — 30×20 with colored zones
  // s=sunglasses(dark), g=gold chain, cl=clothes(red)
  const p = C.pink, s = C.darkGray, g = C.gold, cl = C.brightRed, r = C.reset
  const pig = `
${p}              :;::${r}
${p}            :;+++;${r}
${p} :;++++++;::  :++++; ;+++:${r}
${p}:+++++${s}xX$$$x++++x+;:;${p}++++:${r}
${p}:+xxxx+${s}x$$XXXXx${p}++++++++;:${r}
${p}:++++++${s}X$$$$$X$$$Xx${p}+++;${r}
${p} :+x++++++++xx+X$$$X$$X;:${r}
${p}   ;++++++++++++x$XXXxX$:${r}
${p}     :++x++++++++++xXXXx;${r}
${p}     ;+xXXxx+++++++xXXXx;${r}
${p}     ;++${g}xXXXXXXXx${p}++++++++:${r}
${p}     :+++${g}xXXXXXx${p}+++++++++;${r}
${p}      :;xxx+++++${g}xX$$x${p}xx+:${r}
${p}   ::;x+;+xXXxxxX$Xx+;+::${r}
${cl}:;;:;xXx;;+xXXXXx+;+xXx;:;;:${r}
${cl}:; :+XXXXx;++++++;xXXXX+: ;:${r}
${cl}   :xXXXXXXXx++xXXXXXXXXX;${r}
${cl}   :+XXXXXXXXXXXXXXXXXXXXx:${r}
${cl}   :XXXXXXXXXXXXXXXXXXXXXXX;${r}
${p}      ::::::;;::::::::;;:::${r}`

  const title = `
${C.hotpink}${C.bold}  ____                  ____  _
 |  _ \\ ___  _ __   __ |  _ \\(_) ___ ___
 | |_) / _ \\| '_ \\ / _\`| |_) | |/ __/ _ \\
 |  __/  __/| |_) | (_| |  __/| | (_| (_) |
 |_|   \\___|| .__/ \\__,_|_|   |_|\\___\\___/
             |_|${C.reset}
${C.dim}  Multi-Agent Project Hosting System${C.reset}
${C.dim}  v0.1.0${C.reset}`

  log(pig)
  log(title)
  log('')
}

// ============================================================
//  readline 助手
// ============================================================

let rl: readline.Interface

function initRL() {
  rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout,
  })
}

function ask(prompt: string): Promise<string> {
  return new Promise((res) => rl.question(`${C.cyan}?${C.reset} ${prompt}`, (ans) => res(ans.trim())))
}

function confirm(prompt: string): Promise<boolean> {
  return new Promise((res) => rl.question(`${C.yellow}?${C.reset} ${prompt} [Y/n] `, (ans) => {
    res(ans.trim().toLowerCase() !== 'n')
  }))
}

// ============================================================
//  Provider 创建助手
// ============================================================

function createProvider(
  providersCfg: ProvidersConfig,
  name: string,
): ModelProvider {
  const cfg = providersCfg.providers[name]
  if (!cfg) throw new Error(`Provider "${name}" 未在配置中`)

  switch (cfg.type) {
    case 'openrouter': {
      const apiKey = resolveEnvVar(cfg.apiKey ?? '')
      if (!apiKey) throw new Error(`Provider "${name}" 缺少 apiKey`)
      return createOpenRouter(apiKey)
    }
    case 'openai-compatible': {
      const apiKey = resolveEnvVar(cfg.apiKey ?? '')
      if (!apiKey) throw new Error(`Provider "${name}" 缺少 apiKey`)
      return registerProvider(name, { apiKey, baseURL: cfg.baseUrl })
    }
    case 'copilot': {
      const token = resolveEnvVar(cfg.token ?? cfg.apiKey ?? '')
      if (!token) throw new Error(`Provider "${name}" 缺少 token`)
      return createCopilot(token)
    }
    default:
      throw new Error(`不支持的 provider 类型: ${cfg.type}`)
  }
}

function resolveEnvVar(value: string): string {
  if (value.startsWith('${') && value.endsWith('}')) {
    const envName = value.slice(2, -1)
    return process.env[envName] ?? ''
  }
  return value
}

const providerCache = new Map<string, ModelProvider>()

function createProviderByName(ws: PepacooWorkspace, name: string): ModelProvider {
  if (providerCache.has(name)) return providerCache.get(name)!
  const providersCfg = ws.getProviders()
  const p = createProvider(providersCfg, name)
  providerCache.set(name, p)
  return p
}

// ============================================================
//  模版选择（首次启动时）
// ============================================================

async function pickTemplate(): Promise<string | null> {
  const templates = listTemplates()
  if (templates.length <= 1) return templates[0] ?? null

  log('')
  info('可用的项目配置模版:')
  for (let i = 0; i < templates.length; i++) {
    const t = getTemplate(templates[i])
    const desc = t?.description ? ` — ${t.description}` : ''
    const marker = i === 0 ? ` ${C.dim}(默认)${C.reset}` : ''
    log(`  ${C.dim}${i + 1}${C.reset} ${templates[i]}${desc}${marker}`)
  }
  log(`  ${C.dim}0${C.reset} 不使用模版`)
  log('')
  const choice = await ask('选择模版 [回车=默认]: ')
  if (choice === '0') return null
  const idx = parseInt(choice, 10)
  if (idx >= 1 && idx <= templates.length) return templates[idx - 1]
  return templates[0]
}

/** 将模版 providers 应用到工作区，同时返回是否有有效 key */
function applyTemplateProviders(ws: PepacooWorkspace, template: ProjectTemplate): boolean {
  ws.writeConfig('providers.json', template.providers)
  ws.writeConfig('models.json', template.models)
  if (template.agents) ws.writeConfig('agents.json', template.agents)
  if (template.permissions) ws.writeConfig('permissions.json', template.permissions)
  if (template.scan) ws.writeConfig('scan.json', template.scan)
  // 检查是否有已填入的 key
  for (const [, cfg] of Object.entries(template.providers.providers)) {
    const key = cfg.apiKey || cfg.token || ''
    if (key && !key.startsWith('${')) return true
  }
  return false
}

// ============================================================
//  Session 状态
// ============================================================

interface Session {
  ws: PepacooWorkspace
  os: ByteOS
  coordinator: Agent
  defaultProvider: ModelProvider
  defaultProviderName: string
}

let session: Session | null = null

// ============================================================
//  终端内 Provider 交互式设置
// ============================================================

async function setupProviderInteractive(ws: PepacooWorkspace): Promise<{ provider: ModelProvider; name: string }> {
  const providersCfg = ws.getProviders()

  // 尝试已有配置
  for (const [name, cfg] of Object.entries(providersCfg.providers)) {
    try {
      const p = createProvider(providersCfg, name)
      providerCache.set(name, p)
      ok(`Provider "${name}" 已就绪`)
      return { provider: p, name }
    } catch {
      // 下一个
    }
  }

  // 无可用 provider → 交互式配置
  log('')
  info('未检测到可用的 Provider，请进行配置')
  log(`  ${C.dim}1${C.reset} OpenRouter (推荐 — 支持数百个模型)`)
  log(`  ${C.dim}2${C.reset} GitHub Copilot (需要 Copilot 订阅)`)
  log(`  ${C.dim}3${C.reset} 自定义 OpenAI 兼容 API`)
  log('')

  const choice = await ask('选择 Provider [1/2/3]: ')

  switch (choice) {
    case '1':
    case 'openrouter':
    case '': {
      const apiKey = await ask('OpenRouter API Key: ')
      if (!apiKey) { err('需要 API Key'); process.exit(1) }
      providersCfg.providers.openrouter = { type: 'openrouter', apiKey }
      providersCfg.default = 'openrouter'
      ws.writeConfig('providers.json', providersCfg)
      const p = createOpenRouter(apiKey)
      providerCache.set('openrouter', p)
      ok('OpenRouter 已配置')
      return { provider: p, name: 'openrouter' }
    }
    case '2':
    case 'copilot': {
      let accessToken = ''
      while (!accessToken) {
        info('启动 GitHub OAuth 设备流认证...')
        try {
          const auth = await authenticateCopilot((userCode, uri) => {
            log('')
            log(`${C.bold}  请在浏览器打开:${C.reset} ${C.cyan}${uri}${C.reset}`)
            log(`${C.bold}  输入授权码:${C.reset}    ${C.yellow}${C.bold}${userCode}${C.reset}`)
            log('')
            info('等待授权完成...')
          })
          accessToken = auth.accessToken
        } catch (e) {
          err(`授权失败: ${e instanceof Error ? e.message : String(e)}`)
          if (!(await confirm('是否重试授权？'))) {
            info('跳过 Copilot，请选择其他 Provider')
            return setupProviderInteractive(ws)
          }
        }
      }
      providersCfg.providers.copilot = { type: 'copilot', token: accessToken }
      providersCfg.default = 'copilot'
      ws.writeConfig('providers.json', providersCfg)
      const p = createCopilot(accessToken)
      providerCache.set('copilot', p)
      ok('GitHub Copilot 授权成功！')
      return { provider: p, name: 'copilot' }
    }
    case '3':
    case 'custom': {
      const baseUrl = await ask('API Base URL: ')
      const apiKey = await ask('API Key: ')
      const name = await ask('Provider 名称 [custom]: ') || 'custom'
      providersCfg.providers[name] = { type: 'openai-compatible', apiKey, baseUrl }
      providersCfg.default = name
      ws.writeConfig('providers.json', providersCfg)
      const p = registerProvider(name, { apiKey, baseURL: baseUrl })
      providerCache.set(name, p)
      ok(`${name} 已配置`)
      return { provider: p, name }
    }
    default:
      err('无效选择')
      process.exit(1)
  }
}

// ============================================================
//  核心流程
// ============================================================

function doInit(projectPath: string): PepacooWorkspace {
  const ws = new PepacooWorkspace(projectPath)
  if (ws.isInitialized()) {
    info(`.pepapico/ 已存在，使用现有工作区`)
    return ws
  }
  ws.init()
  ok(`.pepapico/ 已创建于 ${ws.projectPath}`)
  return ws
}

/** 首次初始化 — 带模版选择 */
async function doInitWithTemplate(projectPath: string): Promise<PepacooWorkspace> {
  const ws = new PepacooWorkspace(projectPath)
  if (ws.isInitialized()) {
    info(`.pepapico/ 已存在，使用现有工作区`)
    return ws
  }
  ws.init()
  ok(`.pepapico/ 已创建于 ${ws.projectPath}`)

  // 自动尝试默认模版
  const globalCfg = readGlobalConfig()
  const defaultTpl = getTemplate(globalCfg.defaultTemplate)
  if (defaultTpl) {
    const hasKey = applyTemplateProviders(ws, defaultTpl)
    ok(`已应用模版 "${globalCfg.defaultTemplate}"`)
    if (hasKey) {
      info('模版中已包含 Provider 密钥，跳过手动配置')
      return ws
    }
  }

  // 没有有效 key → 交互式选择其他模版
  const templateName = await pickTemplate()
  if (templateName && templateName !== globalCfg.defaultTemplate) {
    const template = getTemplate(templateName)
    if (template) {
      applyTemplateProviders(ws, template)
      ok(`已应用模版 "${templateName}"`)
    }
  }

  return ws
}

function doScan(ws: PepacooWorkspace): ProjectScan {
  info(`扫描项目: ${ws.projectPath}`)
  const scan = ws.scanProject()
  ok(`扫描完成: ${scan.stats.totalFiles} 文件, ${scan.stats.totalDirs} 目录, ${(scan.stats.totalSizeBytes / 1024).toFixed(1)}KB`)

  const topExts = Object.entries(scan.stats.filesByExtension)
    .sort((a, b) => b[1] - a[1]).slice(0, 5)
    .map(([ext, count]) => `${ext}(${count})`).join(', ')
  log(`  ${C.dim}${topExts}${C.reset}`)

  ws.updateMeta({ alignmentStatus: 'scanned' })
  return scan
}

async function doAlign(
  ws: PepacooWorkspace, os: ByteOS, coordinator: Agent, scan: ProjectScan,
): Promise<string> {
  header('认知对齐')
  ws.updateMeta({ alignmentStatus: 'aligning' })
  info('正在分析项目结构...\n')

  const result = await runWithRetry(os, coordinator, `请分析以下项目，输出结构化认知报告：

${ws.formatScanForPrompt(scan)}

请输出（Markdown 格式）：
## 项目类型 / ## 技术栈 / ## 核心模块(3-8个) / ## 架构模式 / ## 入口文件 / ## 代码规模评估 / ## 关键发现(2-5个)

使用 file_read 工具阅读需要深入了解的文件。`, { context: ws.projectPath })

  let cognition = result.response
  log('\n')
  divider()
  log(cognition)
  divider()

  if (!(await confirm('认知是否准确？(n 可补充修正)'))) {
    const fix = await ask('补充/修正: ')
    if (fix) {
      const r = await runWithRetry(os, coordinator, `用户修正: ${fix}\n\n原报告:\n${cognition}\n\n请更新。`)
      cognition = r.response
      log('\n')
      divider()
      log(cognition)
      divider()
    }
  }

  ws.saveCognition(cognition)
  const typeMatch = cognition.match(/##\s*项目类型\s*\n+([^\n#]+)/)
  const stackMatch = cognition.match(/语言:\s*(.+)/)
  ws.updateMeta({
    alignmentStatus: 'aligned',
    projectCognition: cognition.slice(0, 500),
    projectType: typeMatch?.[1]?.trim(),
    techStack: stackMatch?.[1]?.split(/[,，、]/).map((s) => s.trim()),
  })
  ok('认知对齐完成')
  return cognition
}

async function doPlan(
  ws: PepacooWorkspace, os: ByteOS, coordinator: Agent, cognition: string,
): Promise<SerializedGoalNode[]> {
  header('目标规划')
  const userGoal = await ask('请描述你的任务/目标:\n  ')
  if (!userGoal) { warn('跳过规划'); return [] }

  log('')
  info('生成目标树...')
  const r = await runWithRetry(os, coordinator, `基于项目认知和需求，生成分层目标树。

## 项目认知
${cognition.slice(0, 2000)}

## 用户需求
${userGoal}

输出 JSON (用 \`\`\`json 包裹):
[{ "id":"goal-coordinator", "agentId":"coordinator", "goal":"总目标", "status":"active",
   "children": [{ "id":"goal-worker-1", "agentId":"worker-1", "goal":"子目标", "status":"pending", "children":[] }] }]

规则: 根=coordinator, 子=worker, ≤3层深度, ≤5子节点, goal 要具体可执行, 只输出 JSON。`, { context: ws.projectPath })

  let tree: SerializedGoalNode[] = []
  const m = r.response.match(/```json\s*([\s\S]*?)```/)
  try { tree = JSON.parse(m ? m[1] : r.response) } catch { err('解析失败'); return [] }

  log('\n')
  divider()
  printGoalTree(tree, 0)
  divider()

  if (!(await confirm('同意此目标树？'))) {
    const fix = await ask('修改意见: ')
    if (fix) {
      const f = await runWithRetry(os, coordinator, `修改意见: ${fix}\n原树:\n\`\`\`json\n${JSON.stringify(tree, null, 2)}\n\`\`\`\n输出更新后 JSON。`)
      const fm = f.response.match(/```json\s*([\s\S]*?)```/)
      try { tree = JSON.parse(fm ? fm[1] : f.response); log(''); divider(); printGoalTree(tree, 0); divider() } catch { warn('使用原树') }
    }
  }

  ws.saveGoalTreeSnapshot(tree)
  ok('目标树已保存')
  return tree
}

async function doDeploy(
  ws: PepacooWorkspace, os: ByteOS, coordinator: Agent,
  goalTree: SerializedGoalNode[], provider: ModelProvider,
  modelsCfg: ModelsConfig, agentsCfg: AgentsConfig,
): Promise<void> {
  header('部署子 Agent')

  interface WorkerTask { node: SerializedGoalNode; parentAgent: Agent; depth: number }
  const tasks: WorkerTask[] = []

  function collect(nodes: SerializedGoalNode[], parent: Agent, depth: number) {
    for (const node of nodes) {
      if (node.agentId === coordinator.id || node.agentId === 'coordinator') {
        os.manager.createGoal(coordinator.id, node.goal, [])
        if (node.children?.length) collect(node.children, coordinator, depth + 1)
      } else {
        tasks.push({ node, parentAgent: parent, depth })
      }
    }
  }
  collect(goalTree, coordinator, 1)

  if (!tasks.length) { info('无需创建子 Agent'); return }
  info(`将创建 ${tasks.length} 个子 Agent`)

  const workers: { agent: Agent; task: WorkerTask }[] = []
  for (const task of tasks) {
    const prompt = agentsCfg.workerPromptTemplate
      .replace('{{name}}', task.node.agentId)
      .replace('{{task}}', task.node.goal)
    const dm = modelsCfg.depthOverrides?.[task.depth] ?? modelsCfg.worker
    const wp = createProviderByName(ws, dm.provider)

    const child = task.parentAgent.createChild({
      name: task.node.agentId, role: 'worker',
      systemPrompt: prompt + `\n\n项目路径: ${ws.projectPath}`,
      provider: wp, model: dm.model,
      watchTags: [...agentsCfg.defaultWatchTags],
      autonomous: agentsCfg.autonomousDefaults,
    })
    os.runtime.registerAgent(child)
    os.manager.register(child.id, child.role, child.getDepth())
    os.manager.createGoal(child.id, task.node.goal, [], task.parentAgent.id)
    workers.push({ agent: child, task })
    ok(`${C.bold}${task.node.agentId}${C.reset} (depth=${task.depth}): ${task.node.goal.slice(0, 60)}`)
  }

  ws.updateMeta({ alignmentStatus: 'deployed' })
  divider()
  printAgentTree(coordinator, 0)

  if (!(await confirm('立即执行任务？'))) {
    info('Agent 已创建，通过 /start 手动启动')
    return
  }

  const topWorkers = workers.filter((w) => w.task.parentAgent === coordinator)
  header('执行任务')
  info(`并行启动 ${topWorkers.length} 个 worker...\n`)

  const cog = ws.loadCognition() ?? ''
  const results = await Promise.allSettled(
    topWorkers.map((w) => runWithRetry(os, w.agent,
      `执行任务: ${w.task.node.goal}\n\n项目背景:\n${cog.slice(0, 1000)}\n\n使用工具完成，完成后简洁汇报。`,
      { context: ws.projectPath })),
  )

  log('')
  divider()
  for (let i = 0; i < topWorkers.length; i++) {
    const w = topWorkers[i], r = results[i]
    if (r.status === 'fulfilled') {
      ok(`${C.bold}${w.agent.name}${C.reset}: ${r.value.response.slice(0, 120)}`)
      log(`  ${C.dim}tokens: ${r.value.totalTokens}, turns: ${r.value.turns}${C.reset}`)
    } else {
      err(`${C.bold}${w.agent.name}${C.reset}: ${r.reason}`)
    }
  }

  ws.saveGoalTreeSnapshot(serializeGoalTree(coordinator, os))
  ok('任务完成')
}

// ============================================================
//  给协调者挂载 sub_agent 工具（自动调用子 agent）
// ============================================================

function attachSubAgentTool(coordinator: Agent, ws: PepacooWorkspace, os: ByteOS) {
  const providerMap = new Map<string, { provider: ModelProvider; model: string }>()
  const modelsCfg = ws.getModels()

  for (const [name] of Object.entries(ws.getProviders().providers)) {
    try {
      const p = createProviderByName(ws, name)
      providerMap.set(name, { provider: p, model: modelsCfg.worker.model })
    } catch { /* skip */ }
  }
  if (session) {
    providerMap.set('default', { provider: session.defaultProvider, model: modelsCfg.worker.model })
  }

  const subTool = createSubAgentTool(coordinator, providerMap)
  const idx = coordinator.tools.findIndex((t) => t.name === 'sub_agent')
  if (idx !== -1) coordinator.tools[idx] = subTool
  else coordinator.tools.push(subTool)
}

// ============================================================
//  辅助函数
// ============================================================

function printGoalTree(nodes: SerializedGoalNode[], depth: number): void {
  for (const node of nodes) {
    const indent = '  '.repeat(depth)
    const icon = node.status === 'active' ? '▶' : node.status === 'completed' ? '✓' : '○'
    const color = node.status === 'active' ? C.green : node.status === 'completed' ? C.dim : C.yellow
    log(`${indent}${color}${icon}${C.reset} ${C.bold}${node.agentId}${C.reset}: ${node.goal}`)
    if (node.children?.length) printGoalTree(node.children, depth + 1)
  }
}

function printAgentTree(agent: Agent, depth: number): void {
  const indent = '  '.repeat(depth)
  const icon = agent.role === 'coordinator' ? '🎯' : '🔧'
  const s = agent.status === 'idle' ? C.green + 'idle' : agent.status === 'running' ? C.yellow + 'run' : C.dim + agent.status
  log(`${indent}${icon} ${C.bold}${agent.name}${C.reset} (${s}${C.reset}) [${[...agent.watchTags].slice(0, 3).join(',')}]`)
  for (const child of agent.children) printAgentTree(child, depth + 1)
}

function serializeGoalTree(agent: Agent, os: ByteOS): SerializedGoalNode[] {
  const g = os.manager.getGoal(agent.id)
  return [{ id: g?.id ?? `goal-${agent.id}`, agentId: agent.id, goal: g?.goal ?? agent.name,
    status: g?.status ?? 'pending', children: agent.children.map((c) => serializeGoalTree(c, os)[0]).filter(Boolean) }]
}

function serializeGoalNodeFromGoal(goal: import('./index.ts').GoalNode): SerializedGoalNode {
  return { id: goal.id, agentId: goal.agentId, goal: goal.goal, status: goal.status,
    children: goal.children.map(serializeGoalNodeFromGoal) }
}

function countGoalNodes(nodes: SerializedGoalNode[]): number {
  return nodes.reduce((a, n) => a + 1 + countGoalNodes(n.children ?? []), 0)
}

// ============================================================
//  创建 Session
// ============================================================

async function createSession(projectPath: string, isNew?: boolean): Promise<Session> {
  const ws = isNew ? await doInitWithTemplate(projectPath) : doInit(projectPath)
  const permsCfg = ws.getPermissions()

  const os = new ByteOS({
    autoApproveLevel: permsCfg.autoApproveLevel,
    onEvent: (event) => {
      if (event.type === 'progress' && event.content) process.stdout.write(event.content)
      else if (event.type === 'tool_call') mgrLog(`${C.cyan}${event.agentId}${C.reset} → ${C.yellow}${event.toolName}${C.reset}`)
      else if (event.type === 'tool_result' && event.error) mgrLog(`${C.red}✗ ${event.agentId} ${event.toolName}: ${event.output.slice(0, 120)}${C.reset}`)
      else if (event.type === 'status_change') mgrLog(`${event.agentId}: ${C.dim}${event.from}${C.reset} → ${C.bold}${event.to}${C.reset}`)
      else if (event.type === 'child_created') mgrLog(`${C.green}+ 子Agent${C.reset} ${event.childId} ← ${event.parentId}`)
      else if (event.type === 'child_done') mgrLog(`${C.green}✓ 子完成${C.reset} ${event.notification.agentId}`)
      else if (event.type === 'recycled') mgrLog(`${C.dim}♻ 回收${C.reset} ${event.agentId}`)
    },
    onPermissionRequest: (req) => {
      warn(`权限请求: [${req.risk}] ${req.description}`)
      os.permissionGuard.resolve(req.id, { action: 'allow' })
    },
  })

  // 挂载 AgentManager 事件日志
  os.manager.setEventHandler((event) => {
    switch (event.type) {
      case 'goal_created':
        mgrLog(`${C.green}◉ 目标创建${C.reset} [${event.node.agentId}] ${event.node.goal.slice(0, 80)}`)
        break
      case 'goal_status_changed':
        mgrLog(`◎ 目标状态 ${event.nodeId}: ${C.dim}${event.from}${C.reset} → ${C.bold}${event.to}${C.reset}`)
        break
      case 'escalation_started':
        mgrLog(`${C.yellow}⚡ 上报${C.reset} ${event.request.fromAgentId}: ${event.request.reason.slice(0, 80)}`)
        break
      case 'escalation_reached_root':
        mgrLog(`${C.red}⚡ 到达根节点${C.reset} ${event.request.reason.slice(0, 60)}`)
        break
      case 'needs_human_decision':
        mgrLog(`${C.bgYellow}${C.bold} 需要人工决策 ${C.reset} ${event.pending.suggestion.rationale.slice(0, 80)}`)
        break
      case 'sibling_suspended':
        mgrLog(`${C.yellow}⏸ 挂起${C.reset} ${event.siblingId} ← ${event.reason.slice(0, 60)}`)
        break
      case 'sibling_resumed':
        mgrLog(`${C.green}▶ 恢复${C.reset} ${event.siblingId}`)
        break
      case 'plan_diff_applied':
        mgrLog(`${C.cyan}📋 计划变更已应用${C.reset}`)
        break
    }
  })

  // Provider 在终端内交互式设置
  const { provider, name: providerName } = await setupProviderInteractive(ws)

  const modelsCfg = ws.getModels()
  const agentsCfg = ws.getAgentsConfig()
  const meta = ws.getMeta()

  const coordinator = os.createAgent({
    name: `${meta.projectName}-coordinator`,
    role: 'coordinator',
    systemPrompt: agentsCfg.coordinatorPrompt + `\n\n你有 sub_agent 工具。当任务需要拆分时，主动创建子 Agent 来并行处理子任务。`,
    provider, model: modelsCfg.coordinator.model,
    builtinTools: true,
    watchTags: ['agent:wake', 'fs:watch', 'project:analyze'],
  })

  ws.updateMeta({ coordinatorId: coordinator.id })
  ok(`顶层 Agent: ${coordinator.name} (${modelsCfg.coordinator.model})`)

  const sess: Session = { ws, os, coordinator, defaultProvider: provider, defaultProviderName: providerName }
  session = sess

  // 挂载 sub_agent 工具
  attachSubAgentTool(coordinator, ws, os)

  // 记录到全局最近项目
  addRecentProject(ws.projectPath, meta.projectName)

  return sess
}

// ============================================================
//  完整启动流程
// ============================================================

async function fullStart(projectPath: string): Promise<void> {
  showSplash()
  const sess = await createSession(projectPath, true)
  const { ws, os, coordinator } = sess
  const modelsCfg = ws.getModels()
  const agentsCfg = ws.getAgentsConfig()

  divider()
  const scan = doScan(ws)

  // 空文件夹检测 — 跳过认知对齐，直接收集需求
  if (scan.stats.totalFiles === 0) {
    header('空项目检测')
    info('检测到空文件夹，跳过项目认知对齐')
    log(`  ${C.dim}这是一个全新的项目，请描述你想要构建的内容${C.reset}\n`)
    const requirement = await ask('请描述项目需求:\n  ')
    if (!requirement) { warn('未提供需求，进入交互模式'); await interactiveLoop(); return }

    // 直接进入目标规划（把用户需求作为"认知"）
    const cognition = `# 空项目\n\n## 用户需求\n${requirement}\n\n## 项目路径\n${ws.projectPath}\n\n这是一个空目录，需要从零开始创建所有文件。`
    ws.saveCognition(cognition)
    ws.updateMeta({ alignmentStatus: 'aligned', projectCognition: requirement.slice(0, 500) })

    const goalTree = await doPlan(ws, os, coordinator, cognition)
    if (goalTree.length > 0) {
      await doDeploy(ws, os, coordinator, goalTree, sess.defaultProvider, modelsCfg, agentsCfg)
    }
    await interactiveLoop()
    return
  }

  const cognition = await doAlign(ws, os, coordinator, scan)
  const goalTree = await doPlan(ws, os, coordinator, cognition)
  if (goalTree.length > 0) {
    await doDeploy(ws, os, coordinator, goalTree, sess.defaultProvider, modelsCfg, agentsCfg)
  }
  await interactiveLoop()
}

// ============================================================
//  恢复流程
// ============================================================

async function resumeProject(projectPath: string): Promise<void> {
  showSplash()
  const sess = await createSession(projectPath)
  const { ws, os, coordinator } = sess
  const meta = ws.getMeta()
  const modelsCfg = ws.getModels()
  const agentsCfg = ws.getAgentsConfig()

  info(`恢复: ${meta.projectName} (${meta.alignmentStatus})`)

  const cognition = ws.loadCognition()
  if (cognition) {
    coordinator.messages.push({ role: 'system', content: `[历史项目认知]\n${cognition}` })
    ok('已加载历史认知')
  }

  const savedGoals = ws.loadLatestGoalTree()
  if (savedGoals) ok(`已加载目标树 (${countGoalNodes(savedGoals)} 节点)`)

  if (meta.alignmentStatus === 'not_started' || meta.alignmentStatus === 'scanning') {
    const scan = doScan(ws)
    const cog = await doAlign(ws, os, coordinator, scan)
    const tree = await doPlan(ws, os, coordinator, cog)
    if (tree.length) await doDeploy(ws, os, coordinator, tree, sess.defaultProvider, modelsCfg, agentsCfg)
  } else if (meta.alignmentStatus === 'scanned') {
    const scan = ws.readConfig<ProjectScan>('cognition/latest-scan.json')
    const cog = await doAlign(ws, os, coordinator, scan)
    const tree = await doPlan(ws, os, coordinator, cog)
    if (tree.length) await doDeploy(ws, os, coordinator, tree, sess.defaultProvider, modelsCfg, agentsCfg)
  } else if (meta.alignmentStatus === 'aligned') {
    const tree = await doPlan(ws, os, coordinator, cognition ?? '')
    if (tree.length) await doDeploy(ws, os, coordinator, tree, sess.defaultProvider, modelsCfg, agentsCfg)
  }

  await interactiveLoop()
}

// ============================================================
//  启动教程
// ============================================================

function showTutorial(): void {
  const globalDir = resolveGlobalDir()
  log(`
${C.bold}${C.cyan}╔══════════════════════════════════════════════════════════╗
║              PepaPico 完整启动教程                       ║
╚══════════════════════════════════════════════════════════╝${C.reset}

${C.bold}一、安装与环境${C.reset}

  前置条件:
    - Node.js >= 22.6.0（需要 --experimental-strip-types）
    - npm

  安装:
    ${C.cyan}git clone <repo>${C.reset}
    ${C.cyan}cd Byte_cp${C.reset}
    ${C.cyan}npm install${C.reset}

${C.bold}二、全局配置（首次使用自动创建）${C.reset}

  全局配置目录: ${C.yellow}${globalDir}${C.reset}
  结构:
    ${C.dim}${globalDir}/
      config.json           ← 全局设置
      templates/            ← 项目配置模版
        default/
          template.json     ← 模版元信息
          providers.json    ← Provider + API Key
          models.json       ← 模型配置${C.reset}

  指针文件: ${C.yellow}~/.pepapico-pointer${C.reset}
    ${C.dim}存储全局配置目录的实际路径，支持重定向${C.reset}

  环境变量: ${C.yellow}PEPAPICO_HOME${C.reset}
    ${C.dim}设置后优先使用该路径作为全局配置目录${C.reset}

${C.bold}三、创建项目模版（可选，推荐先做）${C.reset}

  模版用于复用 Provider 凭证和模型配置：

  方式 1 — 命令行交互创建:
    ${C.cyan}/template create my-team${C.reset}
    ${C.dim}按提示添加 Provider、API Key、选择模型${C.reset}

  方式 2 — 从已有项目导出:
    ${C.cyan}/template export my-team${C.reset}
    ${C.dim}将当前 .pepapico/ 配置导出为可复用模版${C.reset}

  方式 3 — 手动编辑:
    ${C.dim}直接编辑 ${globalDir}/templates/<名称>/providers.json${C.reset}

${C.bold}四、托管项目${C.reset}

  启动新项目:
    ${C.cyan}npm run pico${C.reset}                    ← 托管当前目录
    ${C.cyan}npm run pico -- D:\\my-project${C.reset}   ← 托管指定项目

  首次启动流程:
    1. 选择配置模版（若有多个）
    2. 设置 Provider（OpenRouter / GitHub Copilot / 自定义）
    3. 扫描项目结构
    4. 认知对齐（AI 分析项目）
    5. 目标规划（用户描述任务 → AI 生成目标树）
    6. 部署子 Agent → 执行任务
    7. 进入交互式 REPL

  恢复已有项目:
    ${C.dim}如果 .pepapico/ 已存在，自动恢复上次状态${C.reset}

${C.bold}五、Provider 配置说明${C.reset}

  ${C.green}OpenRouter (推荐):${C.reset}
    访问 ${C.cyan}https://openrouter.ai/keys${C.reset} 获取 API Key
    支持数百个模型（Claude, GPT, Gemini, Llama...）

  ${C.green}GitHub Copilot:${C.reset}
    需要 GitHub Copilot 订阅
    启动时自动打开浏览器 OAuth 授权

  ${C.green}自定义 OpenAI 兼容 API:${C.reset}
    任何兼容 OpenAI API 格式的服务
    提供 Base URL 和 API Key

${C.bold}六、全局配置管理命令${C.reset}

  ${C.cyan}/config${C.reset}                    查看全局配置摘要
  ${C.cyan}/config relocate <path>${C.reset}    修改全局配置指向（不移动文件）
  ${C.cyan}/config migrate <path>${C.reset}     移动全局配置到新位置
  ${C.cyan}/config pack [output]${C.reset}      打包导出为 JSON
  ${C.cyan}/config unpack <file>${C.reset}      从打包文件恢复

${C.bold}七、模版管理命令${C.reset}

  ${C.cyan}/template${C.reset}                  列出所有模版
  ${C.cyan}/template create [name]${C.reset}    交互式创建模版
  ${C.cyan}/template export [name]${C.reset}    从当前项目导出
  ${C.cyan}/template apply [name]${C.reset}     应用模版到当前项目
  ${C.cyan}/template delete <name>${C.reset}    删除模版
  ${C.cyan}/template default <name>${C.reset}   设置默认模版

${C.bold}八、项目目录结构${C.reset}

  ${C.dim}my-project/
    .pepapico/
      workspace.json      ← 项目元信息
      providers.json      ← Provider 凭证（可从模版生成）
      models.json         ← 模型映射
      agents.json         ← Agent 行为配置
      permissions.json    ← 权限策略
      scan.json           ← 扫描规则
      cognition/          ← AI 认知结果
      snapshots/          ← 目标树快照
      archives/           ← Agent 记忆归档${C.reset}

${C.bold}九、日常工作流${C.reset}

  ${C.cyan}npm run pico${C.reset}               ← 启动 / 恢复
  ${C.dim}在 REPL 中直接对话，AI 自动创建子 Agent 执行任务${C.reset}
  ${C.cyan}/cd ~/other-project${C.reset}        ← 切换到另一个项目
  ${C.cyan}/template export snapshot${C.reset}  ← 保存当前配置为模版
  ${C.cyan}/config pack backup.json${C.reset}   ← 备份全局配置
  ${C.cyan}/exit${C.reset}                      ← 保存状态并退出
`)
}

// ============================================================
//  交互式 REPL
// ============================================================

async function interactiveLoop(): Promise<void> {
  if (!session) { err('无活跃会话'); return }
  const { ws, os, coordinator } = session

  header('交互模式')
  log(`  ${C.dim}直接输入${C.reset}          与协调者对话${C.dim}（自动调用子 Agent）${C.reset}`)
  log(`  ${C.dim}/provider${C.reset}         管理 Provider`)
  log(`  ${C.dim}/model [name]${C.reset}     切换模型`)
  log(`  ${C.dim}/tree${C.reset}             Agent 树`)
  log(`  ${C.dim}/goals${C.reset}            目标树`)
  log(`  ${C.dim}/status${C.reset}           运行时状态`)
  log(`  ${C.dim}/cd <path>${C.reset}        切换项目 ${C.dim}(重定向)${C.reset}`)
  log(`  ${C.dim}/config${C.reset}           全局配置管理`)
  log(`  ${C.dim}/template${C.reset}         项目模版管理`)
  log(`  ${C.dim}/wake <id>${C.reset}        唤醒 Agent`)
  log(`  ${C.dim}/recycle <id>${C.reset}     回收子 Agent`)
  log(`  ${C.dim}/scan${C.reset}             重新扫描项目`)
  log(`  ${C.dim}/usage${C.reset}            计费报告`)
  log(`  ${C.dim}/tutorial${C.reset}         启动教程`)
  log(`  ${C.dim}/exit${C.reset}             退出`)
  log('')

  const prompt = () => `${C.hotpink}pico${C.reset} ${C.dim}${basename(ws.projectPath)}${C.reset} ${C.dim}>${C.reset} `

  while (true) {
    const input = await new Promise<string>((res) => rl.question(prompt(), res))
    const trimmed = input.trim()
    if (!trimmed) continue

    if (trimmed.startsWith('/')) {
      const [cmd, ...args] = trimmed.slice(1).split(/\s+/)

      switch (cmd) {
        case 'exit': case 'quit': case 'q':
          ws.updateMeta({ lastActiveAt: new Date().toISOString() })
          ws.saveGoalTreeSnapshot(serializeGoalTree(coordinator, os))
          ok('状态已保存，再见！')
          rl.close()
          process.exit(0)
          break

        case 'tree':
          printAgentTree(coordinator, 0)
          break

        case 'goals': {
          const goals = os.manager.getGoalTree()
          if (goals.length) printGoalTree(goals.map(serializeGoalNodeFromGoal), 0)
          else info('目标树为空')
          break
        }

        case 'status': {
          const s = os.getRuntimeStatus()
          log(`  Agent: ${s.totalAgents} (idle=${s.idleAgents} run=${s.runningAgents} auto=${s.autonomousAgents})`)
          log(`  信号: total=${s.signalBusStats.totalSignals} active=${s.signalBusStats.activeListeners}`)
          log(`  Provider: ${session!.defaultProviderName}, Model: ${coordinator.model}`)
          break
        }

        case 'provider': {
          const sub = args[0]
          if (sub === 'add' || sub === 'set' || !sub) {
            const { provider, name } = await setupProviderInteractive(ws)
            session!.defaultProvider = provider
            session!.defaultProviderName = name
            coordinator.provider = provider
            attachSubAgentTool(coordinator, ws, os)
            ok(`默认 Provider 切换为 ${name}`)
          } else if (sub === 'list') {
            const cfg = ws.getProviders()
            for (const [n, c] of Object.entries(cfg.providers)) {
              const marker = n === cfg.default ? `${C.green}●${C.reset}` : `${C.dim}○${C.reset}`
              log(`  ${marker} ${n} (${c.type})`)
            }
          } else {
            log(`  /provider          交互式添加/切换`)
            log(`  /provider list     列出已配置`)
          }
          break
        }

        case 'model':
          if (args[0]) {
            coordinator.model = args[0]
            ok(`模型切换为 ${args[0]}`)
          } else {
            log(`  当前: ${coordinator.model}`)
            info('用法: /model <model-name>')
          }
          break

        case 'cd': case 'open': case 'switch': {
          const target = args.join(' ')
          if (!target) { warn('用法: /cd <项目路径>'); break }
          const absTarget = resolve(target)
          if (!existsSync(absTarget)) { err(`路径不存在: ${absTarget}`); break }
          // 保存当前状态
          ws.updateMeta({ lastActiveAt: new Date().toISOString() })
          ws.saveGoalTreeSnapshot(serializeGoalTree(coordinator, os))
          // 重定向
          providerCache.clear()
          info(`重定向到: ${absTarget}`)
          const newWs = new PepacooWorkspace(absTarget)
          if (newWs.isInitialized()) {
            await resumeProject(absTarget)
          } else {
            await fullStart(absTarget)
          }
          return // 新 REPL 已启动
        }

        case 'scan': {
          const scan = doScan(ws)
          log(`  ${C.dim}关键文件: ${scan.keyFiles.map((f) => f.path).join(', ')}${C.reset}`)
          break
        }

        case 'wake':
          if (args[0]) {
            const ok_ = await os.wakeAgent(args[0], 'user', args.slice(1).join(' ') || 'manual')
            log(ok_ ? `  已唤醒 ${args[0]}` : `  唤醒失败`)
          } else warn('用法: /wake <agentId>')
          break

        case 'recycle':
          if (args[0]) {
            const mem = os.recycleAgent(coordinator.id, args[0])
            if (mem) {
              ok(`已回收 ${mem.agentName}`)
              log(`  ${C.dim}摘要: ${mem.summary.slice(0, 120)}${C.reset}`)
              ws.saveArchive(mem.agentId, mem)
            } else err('回收失败')
          } else warn('用法: /recycle <agentId>')
          break

        case 'usage':
          log(os.printUsageReport())
          break

        case 'help': case 'h': case '?':
          log(`
${C.bold}PepaPico 命令${C.reset}
  /provider [add|list]    Provider 管理
  /model [name]           切换模型
  /cd <path>              切换到另一个项目
  /tree                   Agent 树
  /goals                  目标树
  /status                 运行时状态
  /scan                   重新扫描项目
  /config                 全局配置管理
  /template               项目模版管理
  /wake <id>              唤醒 idle Agent
  /recycle <id>           回收子 Agent
  /usage                  计费报告
  /tutorial               完整启动教程
  /exit                   保存并退出
`)
          break

        case 'config': {
          const sub = args[0]
          if (!sub || sub === 'show') {
            const summary = getGlobalSummary()
            log(`  ${C.bold}全局配置目录:${C.reset} ${summary.globalDir}`)
            log(`  ${C.bold}模版数量:${C.reset}     ${summary.templateCount}`)
            log(`  ${C.bold}默认模版:${C.reset}     ${summary.defaultTemplate}`)
            log(`  ${C.bold}最近项目:${C.reset}     ${summary.recentProjects.length}`)
            if (summary.recentProjects.length > 0) {
              for (const rp of summary.recentProjects.slice(0, 5)) {
                log(`    ${C.dim}${rp.name}${C.reset} → ${rp.path}`)
              }
            }
          } else if (sub === 'relocate') {
            const newPath = args.slice(1).join(' ')
            if (!newPath) { warn('用法: /config relocate <新路径>'); break }
            try {
              const result = relocate(newPath)
              ok(`已将全局配置指向: ${result}`)
            } catch (e) { err(`重定向失败: ${e instanceof Error ? e.message : String(e)}`) }
          } else if (sub === 'migrate') {
            const newPath = args.slice(1).join(' ')
            if (!newPath) { warn('用法: /config migrate <新路径>'); break }
            const yes = await confirm(`将全局配置从当前位置移动到 ${newPath}？`)
            if (!yes) { info('已取消'); break }
            try {
              const result = migrate(newPath)
              ok(`已迁移到: ${result}`)
            } catch (e) { err(`迁移失败: ${e instanceof Error ? e.message : String(e)}`) }
          } else if (sub === 'pack') {
            const output = args[1] || 'pepapico-config.json'
            const absOutput = resolve(output)
            try {
              packConfig(absOutput)
              ok(`已打包到: ${absOutput}`)
            } catch (e) { err(`打包失败: ${e instanceof Error ? e.message : String(e)}`) }
          } else if (sub === 'unpack') {
            const input = args[1]
            if (!input) { warn('用法: /config unpack <文件路径>'); break }
            const absInput = resolve(input)
            if (!existsSync(absInput)) { err(`文件不存在: ${absInput}`); break }
            const yes = await confirm('解包会覆盖当前全局配置，继续？')
            if (!yes) { info('已取消'); break }
            try {
              unpackConfig(absInput)
              ok('解包完成')
            } catch (e) { err(`解包失败: ${e instanceof Error ? e.message : String(e)}`) }
          } else {
            log(`  /config               显示全局配置`)
            log(`  /config relocate <p>  修改配置目录指向`)
            log(`  /config migrate <p>   移动配置到新位置`)
            log(`  /config pack [out]    打包导出配置`)
            log(`  /config unpack <file> 从打包文件恢复`)
          }
          break
        }

        case 'template': case 'tpl': {
          const sub = args[0]
          if (!sub || sub === 'list') {
            const names = listTemplates()
            if (names.length === 0) { info('无模版'); break }
            const gcfg = readGlobalConfig()
            for (const name of names) {
              const t = getTemplate(name)
              const marker = name === gcfg.defaultTemplate ? `${C.green}●${C.reset}` : `${C.dim}○${C.reset}`
              const desc = t?.description ? ` ${C.dim}— ${t.description}${C.reset}` : ''
              const providerNames = t ? Object.keys(t.providers.providers).join(', ') : ''
              log(`  ${marker} ${C.bold}${name}${C.reset}${desc}`)
              if (providerNames) log(`    ${C.dim}providers: ${providerNames}${C.reset}`)
            }
          } else if (sub === 'create') {
            const name = args[1] || await ask('模版名称: ')
            if (!name) { warn('需要名称'); break }
            const desc = await ask('描述 (可选): ')
            info('配置 Provider（回车跳过）')
            const providers: ProvidersConfig = { default: '', providers: {} }
            let adding = true
            while (adding) {
              log(`  ${C.dim}类型: 1=OpenRouter 2=Copilot 3=自定义 0=完成${C.reset}`)
              const pChoice = await ask('添加 Provider: ')
              if (pChoice === '0' || !pChoice) { adding = false; break }
              if (pChoice === '1') {
                const key = await ask('OpenRouter API Key: ')
                providers.providers.openrouter = { type: 'openrouter', apiKey: key }
                if (!providers.default) providers.default = 'openrouter'
              } else if (pChoice === '2') {
                providers.providers.copilot = { type: 'copilot', token: '' }
                if (!providers.default) providers.default = 'copilot'
                info('Copilot 需运行时 OAuth 认证，模版中不存储 token')
              } else if (pChoice === '3') {
                const pName = await ask('Provider 名称: ')
                const baseUrl = await ask('API Base URL: ')
                const apiKey = await ask('API Key: ')
                if (pName) {
                  providers.providers[pName] = { type: 'openai-compatible', apiKey, baseUrl }
                  if (!providers.default) providers.default = pName
                }
              }
            }
            if (!providers.default && Object.keys(providers.providers).length > 0) {
              providers.default = Object.keys(providers.providers)[0]
            }
            const tpl: ProjectTemplate = {
              name,
              providers,
              models: ws.getModels(),
              description: desc || undefined,
              createdAt: new Date().toISOString(),
              updatedAt: new Date().toISOString(),
            }
            saveTemplate(tpl)
            ok(`模版 "${name}" 已创建`)
          } else if (sub === 'export') {
            const name = args[1] || await ask('导出为模版名: ')
            if (!name) { warn('需要名称'); break }
            const desc = await ask('描述 (可选): ')
            try {
              exportProjectAsTemplate(ws.pepacooDir, name, desc || undefined)
              ok(`当前项目配置已导出为模版 "${name}"`)
            } catch (e) { err(`导出失败: ${e instanceof Error ? e.message : String(e)}`) }
          } else if (sub === 'apply') {
            const name = args[1] || await ask('模版名: ')
            if (!name) { warn('需要名称'); break }
            const yes = await confirm(`将模版 "${name}" 应用到当前项目？（覆盖配置）`)
            if (!yes) { info('已取消'); break }
            if (applyTemplateToProject(name, ws.pepacooDir)) {
              ok(`模版 "${name}" 已应用`)
              info('下次运行时生效')
            } else { err(`模版 "${name}" 不存在`) }
          } else if (sub === 'delete') {
            const name = args[1]
            if (!name) { warn('用法: /template delete <名称>'); break }
            const yes = await confirm(`确认删除模版 "${name}"？`)
            if (!yes) { info('已取消'); break }
            if (deleteTemplate(name)) ok(`已删除模版 "${name}"`)
            else err(`模版 "${name}" 不存在`)
          } else if (sub === 'default') {
            const name = args[1]
            if (!name) { warn('用法: /template default <名称>'); break }
            if (!getTemplate(name)) { err(`模版 "${name}" 不存在`); break }
            updateGlobalConfig({ defaultTemplate: name })
            ok(`默认模版已设为 "${name}"`)
          } else {
            log(`  /template               列出所有模版`)
            log(`  /template create [n]    创建新模版（交互式）`)
            log(`  /template export [n]    从当前项目导出模版`)
            log(`  /template apply [n]     将模版应用到当前项目`)
            log(`  /template delete <n>    删除模版`)
            log(`  /template default <n>   设置默认模版`)
          }
          break
        }

        case 'tutorial': {
          showTutorial()
          break
        }
          break

        default:
          warn(`未知命令: /${cmd} — /help 查看帮助`)
      }
    } else {
      // 自然语言 → 协调者（已挂载 sub_agent 工具，会自动创建子 agent）
      try {
        const result = await runWithRetry(os, coordinator, trimmed, { context: ws.projectPath })
        log('\n' + result.response)
        log(`${C.dim}  [tokens: ${result.totalTokens}, turns: ${result.turns}]${C.reset}`)
        if (coordinator.children.length > 0) {
          ws.saveGoalTreeSnapshot(serializeGoalTree(coordinator, os))
        }
      } catch (e) {
        err(`${e instanceof Error ? e.message : String(e)}`)
      }
    }
    log('')
  }
}

// ============================================================
//  CLI 入口 — 极简: npm run pico [path]
// ============================================================

async function main() {
  const args = process.argv.slice(2)
  initRL()

  // 初始化全局配置
  const globalDir = initGlobalConfig()

  const projectPath = resolve(args[0] ?? '.')

  if (!existsSync(projectPath)) {
    err(`路径不存在: ${projectPath}`)
    process.exit(1)
  }

  const ws = new PepacooWorkspace(projectPath)
  if (ws.isInitialized()) {
    await resumeProject(projectPath)
  } else {
    await fullStart(projectPath)
  }
}

main().catch((e) => {
  const msg = e instanceof Error ? e.message : String(e)
  err(`致命错误: ${msg}`)
  if (msg.includes('model') || msg.includes('API error') || msg.includes('400')) {
    info('提示: 这可能是模型配置问题，请检查 .pepapico/models.json 中的模型名称')
    info('或使用 /model <name> 命令在 REPL 中切换模型')
  }
  process.exit(1)
})
