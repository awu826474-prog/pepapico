/**
 * PepaPico Workspace — 项目托管文件夹管理
 *
 * 在目标项目目录下创建 `.pepapico/` 文件夹，持久化存储：
 *   - 配置（模型/权限/自主行为/Provider 等）
 *   - Agent 树状态与目标树快照
 *   - 压缩记忆归档
 *   - 项目认知快照
 *
 * 核心流程：
 *   init → scan → align → deploy
 */

import { existsSync, mkdirSync, writeFileSync, readFileSync, readdirSync, statSync } from 'node:fs'
import { join, basename, relative, resolve } from 'node:path'

// ============================================================
//  配置文件类型
// ============================================================

/** 各级默认模型配置 — .pepapico/models.json */
export interface ModelsConfig {
  /** 顶层协调者模型 */
  coordinator: { provider: string; model: string }
  /** worker 默认模型 */
  worker: { provider: string; model: string }
  /** 快速扫描用的轻量模型 */
  scanner: { provider: string; model: string }
  /** 按深度覆盖 — depth → {provider, model} */
  depthOverrides?: Record<number, { provider: string; model: string }>
  /** 按 tag 覆盖 — tag → {provider, model} */
  tagOverrides?: Record<string, { provider: string; model: string }>
}

/** Provider 凭证配置 — .pepapico/providers.json */
export interface ProvidersConfig {
  default: string
  providers: Record<string, {
    type: 'openrouter' | 'copilot' | 'openai-compatible' | 'nano-banana'
    apiKey?: string
    token?: string
    baseUrl?: string
  }>
}

/** Agent 默认行为配置 — .pepapico/agents.json */
export interface AgentsConfig {
  /** 顶层 agent 的 system prompt 模板 */
  coordinatorPrompt: string
  /** worker system prompt 模板（支持 {{name}} {{task}} 占位符） */
  workerPromptTemplate: string
  /** 默认 watchTags */
  defaultWatchTags: string[]
  /** 自主模式默认配置 */
  autonomousDefaults: {
    enabled: boolean
    maxAutoRuns: number
    autoApproveTools: string[]
  }
  /** 最大递归深度 */
  maxDepth: number
  /** 每个 agent 最大子节点数 */
  maxChildren: number
}

/** 权限策略配置 — .pepapico/permissions.json */
export interface PermissionsConfig {
  /** 自动放行风险等级 */
  autoApproveLevel: 'low' | 'medium' | 'high'
  /** 全局禁用的工具 */
  globalDeniedTools: string[]
  /** worker 允许的工具（* 表示全部） */
  workerAllowedTools: string[] | '*'
  /** 需要人工确认的 bash 命令模式 */
  dangerousPatterns: string[]
}

/** 项目扫描配置 — .pepapico/scan.json */
export interface ScanConfig {
  /** 忽略的目录 */
  ignoreDirs: string[]
  /** 忽略的文件模式 */
  ignorePatterns: string[]
  /** 最大扫描深度 */
  maxDepth: number
  /** 大文件阈值（字节），超过则只读取开头 */
  largeFileThreshold: number
  /** 关键文件（优先读取） */
  keyFiles: string[]
}

/** 工作区元信息 — .pepapico/workspace.json */
export interface WorkspaceMeta {
  /** 项目名称 */
  projectName: string
  /** 项目路径 */
  projectPath: string
  /** 创建时间 */
  createdAt: string
  /** 最后活跃时间 */
  lastActiveAt: string
  /** 当前顶层 agent ID（如有） */
  coordinatorId?: string
  /** 认知对齐状态 */
  alignmentStatus: 'not_started' | 'scanning' | 'scanned' | 'aligning' | 'aligned' | 'deployed'
  /** 项目认知摘要（扫描后填入） */
  projectCognition?: string
  /** 项目类型 */
  projectType?: string
  /** 主要技术栈 */
  techStack?: string[]
}

/** 持久化的目标树节点 */
export interface SerializedGoalNode {
  id: string
  agentId: string
  goal: string
  status: string
  children: SerializedGoalNode[]
}

// ============================================================
//  默认配置
// ============================================================

const DEFAULT_MODELS: ModelsConfig = {
  coordinator: { provider: 'openrouter', model: 'anthropic/claude-sonnet-4-5' },
  worker: { provider: 'openrouter', model: 'anthropic/claude-sonnet-4-5' },
  scanner: { provider: 'openrouter', model: 'anthropic/claude-sonnet-4-5' },
}

const DEFAULT_PROVIDERS: ProvidersConfig = {
  default: 'openrouter',
  providers: {
    openrouter: {
      type: 'openrouter',
      apiKey: '${OPENROUTER_API_KEY}',
    },
  },
}

const DEFAULT_AGENTS: AgentsConfig = {
  coordinatorPrompt: `你是项目顶层协调者 Agent。你的职责是：
1. 理解项目整体结构和用户的需求
2. 将任务分解为子目标，分配给子 Agent
3. 监控子 Agent 进度，必要时干预或回收
4. 综合结果生成最终报告

项目信息会在认知对齐阶段注入。用中文回答。`,
  workerPromptTemplate: `你是 {{name}}，负责执行以下任务：
{{task}}

规则：
- 只关注你被分配的任务，不要越界
- 完成后简洁汇报结果
- 遇到无法解决的问题及时上报
- 用中文回答`,
  defaultWatchTags: ['agent:wake'],
  autonomousDefaults: {
    enabled: false,
    maxAutoRuns: 10,
    autoApproveTools: ['file_read'],
  },
  maxDepth: 4,
  maxChildren: 8,
}

const DEFAULT_PERMISSIONS: PermissionsConfig = {
  autoApproveLevel: 'low',
  globalDeniedTools: [],
  workerAllowedTools: '*',
  dangerousPatterns: [
    'rm -rf', 'rmdir /s', 'del /f',
    'git push --force', 'git reset --hard',
    'DROP TABLE', 'DROP DATABASE',
    'chmod 777', 'mkfs',
  ],
}

const DEFAULT_SCAN: ScanConfig = {
  ignoreDirs: [
    'node_modules', '.git', '.next', 'dist', 'build', '__pycache__',
    '.venv', 'venv', '.pepapico', '.pepacoo', 'coverage', '.cache', '.turbo',
    'target', 'vendor', 'Pods', '.gradle',
  ],
  ignorePatterns: [
    '*.lock', '*.min.js', '*.min.css', '*.map',
    '*.png', '*.jpg', '*.jpeg', '*.gif', '*.ico', '*.svg',
    '*.woff', '*.woff2', '*.ttf', '*.eot',
    '*.exe', '*.dll', '*.so', '*.dylib',
    '*.zip', '*.tar.gz', '*.rar',
  ],
  maxDepth: 5,
  largeFileThreshold: 50 * 1024, // 50KB
  keyFiles: [
    'package.json', 'tsconfig.json', 'pyproject.toml', 'requirements.txt',
    'Cargo.toml', 'go.mod', 'pom.xml', 'build.gradle',
    'Makefile', 'Dockerfile', 'docker-compose.yml',
    'README.md', 'README', '.env.example',
  ],
}

// ============================================================
//  PepaPicoWorkspace 类（兼容别名 PepacooWorkspace）
// ============================================================

export class PepacooWorkspace {
  readonly projectPath: string
  readonly pepacooDir: string

  constructor(projectPath: string) {
    this.projectPath = resolve(projectPath)
    this.pepacooDir = join(this.projectPath, '.pepapico')
  }

  /** 检查是否已初始化 */
  isInitialized(): boolean {
    return existsSync(this.pepacooDir) && existsSync(join(this.pepacooDir, 'workspace.json'))
  }

  // ---- 初始化 ----

  /**
   * 初始化 .pepapico/ 工作区
   * 创建所有配置文件的默认版本
   */
  init(options?: {
    provider?: string
    apiKey?: string
    model?: string
  }): WorkspaceMeta {
    if (this.isInitialized()) {
      throw new Error(`.pepapico/ 已存在于 ${this.projectPath}，使用 resume 恢复`)
    }

    // 创建目录结构
    mkdirSync(this.pepacooDir, { recursive: true })
    mkdirSync(join(this.pepacooDir, 'archives'), { recursive: true })
    mkdirSync(join(this.pepacooDir, 'snapshots'), { recursive: true })
    mkdirSync(join(this.pepacooDir, 'cognition'), { recursive: true })

    // 写入默认配置
    const models = { ...DEFAULT_MODELS }
    if (options?.model) {
      models.coordinator = { ...models.coordinator, model: options.model }
      models.worker = { ...models.worker, model: options.model }
    }

    const providers = { ...DEFAULT_PROVIDERS }
    if (options?.provider) {
      providers.default = options.provider
    }
    if (options?.apiKey && options?.provider) {
      providers.providers[options.provider] = {
        type: options.provider as ProvidersConfig['providers'][string]['type'],
        apiKey: options.apiKey,
      }
    }

    this.writeConfig('models.json', models)
    this.writeConfig('providers.json', providers)
    this.writeConfig('agents.json', DEFAULT_AGENTS)
    this.writeConfig('permissions.json', DEFAULT_PERMISSIONS)
    this.writeConfig('scan.json', DEFAULT_SCAN)

    // 写入 .gitignore 建议
    const gitignorePath = join(this.pepacooDir, '.gitignore')
    writeFileSync(gitignorePath, `# PepaPico workspace — 不建议提交凭证
providers.json
archives/
snapshots/
cognition/
`)

    // 工作区元信息
    const meta: WorkspaceMeta = {
      projectName: basename(this.projectPath),
      projectPath: this.projectPath,
      createdAt: new Date().toISOString(),
      lastActiveAt: new Date().toISOString(),
      alignmentStatus: 'not_started',
    }
    this.writeConfig('workspace.json', meta)

    return meta
  }

  // ---- 配置读写 ----

  writeConfig(filename: string, data: unknown): void {
    writeFileSync(join(this.pepacooDir, filename), JSON.stringify(data, null, 2), 'utf-8')
  }

  readConfig<T>(filename: string): T {
    const filepath = join(this.pepacooDir, filename)
    if (!existsSync(filepath)) {
      throw new Error(`配置文件不存在: ${filename}`)
    }
    return JSON.parse(readFileSync(filepath, 'utf-8')) as T
  }

  readConfigSafe<T>(filename: string, fallback: T): T {
    try {
      return this.readConfig<T>(filename)
    } catch {
      return fallback
    }
  }

  // ---- 快捷读取 ----

  getMeta(): WorkspaceMeta {
    return this.readConfig<WorkspaceMeta>('workspace.json')
  }

  updateMeta(patch: Partial<WorkspaceMeta>): WorkspaceMeta {
    const meta = this.getMeta()
    const updated = { ...meta, ...patch, lastActiveAt: new Date().toISOString() }
    this.writeConfig('workspace.json', updated)
    return updated
  }

  getModels(): ModelsConfig {
    return this.readConfig<ModelsConfig>('models.json')
  }

  getProviders(): ProvidersConfig {
    return this.readConfig<ProvidersConfig>('providers.json')
  }

  getAgentsConfig(): AgentsConfig {
    return this.readConfig<AgentsConfig>('agents.json')
  }

  getPermissions(): PermissionsConfig {
    return this.readConfig<PermissionsConfig>('permissions.json')
  }

  getScanConfig(): ScanConfig {
    return this.readConfig<ScanConfig>('scan.json')
  }

  // ---- 项目扫描 ----

  /**
   * 快速扫描项目结构
   * 返回结构化的目录树 + 关键文件内容
   */
  scanProject(): ProjectScan {
    const scanConfig = this.getScanConfig()
    const tree = this.buildTree(this.projectPath, 0, scanConfig)
    const keyFileContents = this.readKeyFiles(scanConfig)

    const scan: ProjectScan = {
      projectName: basename(this.projectPath),
      tree,
      keyFiles: keyFileContents,
      stats: this.collectStats(this.projectPath, scanConfig),
      scannedAt: new Date().toISOString(),
    }

    // 保存扫描结果
    this.writeConfig('cognition/latest-scan.json', scan)
    return scan
  }

  /** 构建目录树字符串 */
  private buildTree(dir: string, depth: number, config: ScanConfig): string {
    if (depth > config.maxDepth) return ''

    let entries: ReturnType<typeof readdirSync>
    try {
      entries = readdirSync(dir, { withFileTypes: true })
    } catch {
      return ''
    }

    const lines: string[] = []
    const indent = '  '.repeat(depth)
    const ignoreSet = new Set(config.ignoreDirs)

    for (const entry of entries) {
      // 忽略目录
      if (entry.isDirectory() && ignoreSet.has(entry.name)) {
        lines.push(`${indent}${entry.name}/ [ignored]`)
        continue
      }

      // 忽略文件模式
      if (!entry.isDirectory() && this.matchesPattern(entry.name, config.ignorePatterns)) {
        continue
      }

      if (entry.isDirectory()) {
        lines.push(`${indent}${entry.name}/`)
        const sub = this.buildTree(join(dir, entry.name), depth + 1, config)
        if (sub) lines.push(sub)
      } else {
        try {
          const s = statSync(join(dir, entry.name))
          const size = s.size > 1024 ? `${(s.size / 1024).toFixed(1)}KB` : `${s.size}B`
          lines.push(`${indent}${entry.name} (${size})`)
        } catch {
          lines.push(`${indent}${entry.name}`)
        }
      }
    }

    return lines.join('\n')
  }

  /** 读取关键文件内容 */
  private readKeyFiles(config: ScanConfig): KeyFileContent[] {
    const results: KeyFileContent[] = []

    for (const keyFile of config.keyFiles) {
      const absPath = join(this.projectPath, keyFile)
      if (!existsSync(absPath)) continue

      try {
        const s = statSync(absPath)
        let content = readFileSync(absPath, 'utf-8')

        // 大文件截断
        if (s.size > config.largeFileThreshold) {
          content = content.slice(0, config.largeFileThreshold) + '\n\n... [文件已截断，共 ' + s.size + ' 字节]'
        }

        results.push({
          path: keyFile,
          content,
          size: s.size,
        })
      } catch {
        // 跳过无法读取的文件
      }
    }

    return results
  }

  /** 收集项目统计信息 */
  private collectStats(root: string, config: ScanConfig): ProjectStats {
    const stats: ProjectStats = {
      totalFiles: 0,
      totalDirs: 0,
      filesByExtension: {},
      totalSizeBytes: 0,
    }

    this.walkForStats(root, 0, config, stats)
    return stats
  }

  private walkForStats(dir: string, depth: number, config: ScanConfig, stats: ProjectStats): void {
    if (depth > config.maxDepth) return

    let entries: ReturnType<typeof readdirSync>
    try {
      entries = readdirSync(dir, { withFileTypes: true })
    } catch {
      return
    }

    const ignoreSet = new Set(config.ignoreDirs)

    for (const entry of entries) {
      if (entry.isDirectory()) {
        if (ignoreSet.has(entry.name)) continue
        stats.totalDirs++
        this.walkForStats(join(dir, entry.name), depth + 1, config, stats)
      } else {
        if (this.matchesPattern(entry.name, config.ignorePatterns)) continue
        stats.totalFiles++
        const ext = entry.name.includes('.') ? '.' + entry.name.split('.').pop()! : '(no ext)'
        stats.filesByExtension[ext] = (stats.filesByExtension[ext] ?? 0) + 1

        try {
          const s = statSync(join(dir, entry.name))
          stats.totalSizeBytes += s.size
        } catch { /* ignore */ }
      }
    }
  }

  private matchesPattern(filename: string, patterns: string[]): boolean {
    for (const pattern of patterns) {
      // 简单通配符匹配 *.ext
      if (pattern.startsWith('*.')) {
        if (filename.endsWith(pattern.slice(1))) return true
      } else if (filename === pattern) {
        return true
      }
    }
    return false
  }

  // ---- 持久化 ----

  /** 保存目标树快照 */
  saveGoalTreeSnapshot(tree: SerializedGoalNode[]): void {
    const filename = `snapshots/goals-${Date.now()}.json`
    this.writeConfig(filename, tree)
    this.writeConfig('snapshots/goals-latest.json', tree)
  }

  /** 加载最新目标树 */
  loadLatestGoalTree(): SerializedGoalNode[] | null {
    try {
      return this.readConfig<SerializedGoalNode[]>('snapshots/goals-latest.json')
    } catch {
      return null
    }
  }

  /** 保存压缩记忆归档 */
  saveArchive(agentId: string, memory: unknown): void {
    this.writeConfig(`archives/${agentId}.json`, memory)
  }

  /** 保存认知文档 */
  saveCognition(content: string): void {
    writeFileSync(join(this.pepacooDir, 'cognition', 'project-cognition.md'), content, 'utf-8')
  }

  /** 读取认知文档 */
  loadCognition(): string | null {
    const path = join(this.pepacooDir, 'cognition', 'project-cognition.md')
    if (!existsSync(path)) return null
    return readFileSync(path, 'utf-8')
  }

  // ---- 格式化输出 ----

  /** 生成扫描报告的 prompt 文本 */
  formatScanForPrompt(scan: ProjectScan): string {
    const fileExtSummary = Object.entries(scan.stats.filesByExtension)
      .sort((a, b) => b[1] - a[1])
      .slice(0, 15)
      .map(([ext, count]) => `  ${ext}: ${count} 个`)
      .join('\n')

    const keyFileSections = scan.keyFiles
      .map((kf) => `--- ${kf.path} (${kf.size > 1024 ? (kf.size / 1024).toFixed(1) + 'KB' : kf.size + 'B'}) ---\n${kf.content}`)
      .join('\n\n')

    return `# 项目: ${scan.projectName}

## 目录结构
\`\`\`
${scan.projectName}/
${scan.tree}
\`\`\`

## 统计
- 文件数: ${scan.stats.totalFiles}
- 目录数: ${scan.stats.totalDirs}
- 总大小: ${(scan.stats.totalSizeBytes / 1024).toFixed(1)}KB

## 文件类型分布
${fileExtSummary}

## 关键文件内容
${keyFileSections}
`
  }
}

// ---- 辅助类型 ----

export interface KeyFileContent {
  path: string
  content: string
  size: number
}

export interface ProjectStats {
  totalFiles: number
  totalDirs: number
  filesByExtension: Record<string, number>
  totalSizeBytes: number
}

export interface ProjectScan {
  projectName: string
  tree: string
  keyFiles: KeyFileContent[]
  stats: ProjectStats
  scannedAt: string
}
